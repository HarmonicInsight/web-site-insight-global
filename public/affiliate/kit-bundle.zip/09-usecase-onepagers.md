# Industry Use-Case One-Pagers / 業界別ユースケース

> 業界・ターゲット別に「**この業界ならこう刺さる**」をまとめた1ページ資料集。アフィリエーターが特定業界向けの記事・LP・ピッチを作る素材。

---

# 🇯🇵 日本語版（5業界）

## 1. 建設業バックオフィス

### この業界の課題
- **外国人技能実習生の急増**: 2027年4月施行の「育成就労制度」で外国人就労者がさらに増加見込み
- **多言語安全教育の義務化**: 安全衛生教育を母国語で行うことが法令上推奨
- **元請け責任の拡大**: 重大事故時、教育記録の提示が求められる
- **人手不足**: 教材制作担当者を専任で置けない中小元請けが多い

### HARMONIC insight が刺さる理由

| 課題 | 解決 |
|------|------|
| 母国語での安全教育コンテンツが必要 | **Insight Training Studio** で PPT を13言語の動画化 |
| 教材を毎月更新する負担が重い | バッチ処理で複数言語版を一括出力 |
| クラウド送信は社内規定でNG | ローカル処理のみ。クラウド送信ゼロ |
| 教育担当者が翻訳まで対応できない | AI が自動翻訳 + ナレーション自動生成 |

### 想定ROI（売上¥3億の中小元請け）
- 旧フロー（外注）: 5言語 × 月10本 = 月¥100万 + 制作期間2週間
- 新フロー（IDT+ITS）: 月¥1,667 + 制作期間1日（30分の自動処理）
- **削減効果: 月¥98万、年¥1,176万**

### 推奨パッケージ
- Insight Training Studio Business（¥50,000/年）
- Insight Doc Translator Personal（¥20,000/年、契約書類翻訳用）
- 合計: 年¥70,000 で年1,000万円超の削減

### 想定アフィリエイト先
- 建設業界紙、建設DX系メディア
- 行政書士・社労士事務所（特定技能管理事業者向け）
- 安全衛生コンサル

### 営業トーク例
> 「2027年の育成就労制度で、外国人作業員の安全教育がさらに重要になります。母国語動画教材の量産が必須になる中、HARMONIC insight の Insight Training Studio なら、PowerPoint 1枚から13言語のMP4が30分で出力できます。クラウド送信ゼロなので、御社の情報セキュリティ規定にも適合します。」

---

## 2. 教育機関（学校・eラーニング事業者）

### この業界の課題
- **多文化共生**: 公立学校で外国人児童生徒が急増、母国語サポートが必須
- **eラーニング教材の多言語化**: 英語版だけでは留学生・海外展開に不十分
- **教員の負担**: 教材制作だけで翻訳・吹き替えまで手が回らない
- **予算制約**: 公立校・私学とも翻訳外注予算が限られる

### HARMONIC insight が刺さる理由

| 課題 | 解決 |
|------|------|
| 教材を13言語で展開したい | ITS で PPT → 多言語 MP4 |
| 配布資料も翻訳が必要 | IDT で PPTX/DOCX/XLSX 翻訳 |
| 教員が技術的に苦手 | クリックだけのシンプルUI |
| 予算が少ない | 月¥1,667〜、API課金は使った分だけ |

### 推奨パッケージ
- Insight Doc Translator Personal（¥20,000/年）
- Insight Training Studio Personal（¥20,000/年）
- 合計: 年¥40,000

### 想定アフィリエイト先
- 教員向けメディア（教職員ジャーナル等）
- eラーニング系YouTuber
- 教材制作会社

### 営業トーク例
> 「eラーニング教材を英語以外の言語にも展開したいけれど、翻訳と吹き替えのコストが膨大。Insight Training Studio なら、PowerPoint をそのまま渡すだけで、13言語のナレーション付き動画が自動生成されます。月¥1,667 で、教材1本分の翻訳費用を下回ります。」

---

## 3. 医療・製薬

### この業界の課題
- **規制対応**: 医療情報のクラウド送信は HIPAA・個人情報保護法で厳格制限
- **多言語患者対応**: 在日外国人患者向け説明文書・同意書の母国語化
- **製薬規制文書**: PMDA、EMA、FDA 提出資料の多言語版必須
- **正確性が命**: 誤訳が医療事故・規制違反に直結

### HARMONIC insight が刺さる理由

| 課題 | 解決 |
|------|------|
| クラウド翻訳禁止規定 | **完全ローカル処理 + BYOK** |
| 専門用語の精度 | エンジン切替で Claude/DeepL/Azure を使い分け |
| 患者向け資料の多言語化 | IDT でワンクリック翻訳、書式維持 |
| バリデーション必須 | 5エンジン併用で結果比較・人間チェック容易 |

### 推奨パッケージ
- Insight Doc Translator Business（¥50,000/年）※ バッチ処理必須
- Azure OpenAI Private 環境を推奨

### 想定アフィリエイト先
- 医療情報学会の発表者
- 医療コンサル
- 製薬関連メディア

### 営業トーク例
> 「患者向け説明文書の多言語化、いまどうしていますか？クラウド翻訳サービスは HIPAA・個人情報保護法に抵触する可能性があります。Insight Doc Translator なら、御院内サーバーで完結し、Azure OpenAI のプライベート環境を使えばエンジン側もクラウド送信ゼロにできます。同意書、診療情報提供書、患者教材まで対応可能です。」

---

## 4. 法律事務所・ビジネス契約

### この業界の課題
- **守秘義務**: 契約書・準備書面のクラウド送信は守秘義務違反リスク
- **国際案件の増加**: M&A、海外進出、輸出入で英文契約書ニーズ拡大
- **正確性とニュアンス**: 法的拘束力ある文書での誤訳リスク
- **時間圧力**: クライアントから即日翻訳を求められるケース

### HARMONIC insight が刺さる理由

| 課題 | 解決 |
|------|------|
| 守秘義務でクラウド送信不可 | 完全ローカル処理 |
| 法律用語の精度 | Claude エンジンで文脈精度を高める |
| Word 形式の書式維持 | 段落・脚注・コメント・字下げを完全保持 |
| 即日対応 | 100ページの契約書も30分で初稿翻訳 |

### 推奨パッケージ
- Insight Doc Translator Business（¥50,000/年）
- Claude Pro（API契約）

### 想定アフィリエイト先
- リーガルテックメディア
- 弁護士向け SaaS レビュアー
- 国際業務コンサル

### 営業トーク例
> 「クライアント機密の契約書を翻訳するとき、DeepL に上げていいか迷ったことありませんか？Insight Doc Translator は、Word ファイルを御事務所内で処理し、翻訳エンジン（Claude推奨）に送るのは必要な部分だけ。守秘義務に抵触せず、Word 書式を完全に保ちます。100ページの英文契約書も30分で初稿が出ます。」

---

## 5. 個人事業主・コンサル・クリエイター

### この業界の課題
- **多言語クライアント対応**: 海外のクライアント、海外進出クライアント
- **コスト感覚**: 翻訳会社（1文字¥10〜30）は予算的に厳しい
- **時間制約**: 1人で営業から納品まで全部
- **品質と速度の両立**: クライアントから「明日までに英語版」を求められる

### HARMONIC insight が刺さる理由

| 課題 | 解決 |
|------|------|
| 翻訳費用を抑えたい | 月¥1,667〜、APIキーは自分の分だけ |
| 即日納品 | クリック1つで翻訳完了 |
| PowerPoint プレゼン資料 | 書式完全保持で見栄え劣化なし |
| 月によって使用量変動 | サブスクなので使わない月もコスト固定 |

### 推奨パッケージ
- Insight Doc Translator Personal（¥20,000/年）
- DeepL API（使った分だけ、月¥0〜2,000程度）

### 想定アフィリエイト先
- 個人事業主向け税理士・経営コンサル
- フリーランス系YouTuber、Note等
- クラウドソーシング系メディア

### 営業トーク例
> 「海外クライアント向けに提案書を英訳するとき、毎回翻訳会社に出してました？月¥1,667 の Insight Doc Translator なら、自分でクリック1つ。DeepL API も自分で契約するから、使った分だけ。提案書20本/月でも、合計コストは¥3,000を切ります。納期は当日。」

---

# 🇺🇸 English Version (5 industries)

## 1. Construction Back-Office

### Industry challenges
- **Foreign worker influx**: New US, EU, and global immigration patterns
- **Multilingual safety training compliance**: OSHA-style regulations require native-language safety education
- **General contractor liability**: Training records demanded after incidents
- **Resource constraints**: Mid-size GCs can't dedicate full-time content creators

### Why HARMONIC insight wins

| Challenge | Solution |
|-----------|----------|
| Native-language safety content | **Insight Training Studio** for PPT → 13-language video |
| Monthly content updates burdensome | Batch processing for parallel multilingual output |
| Cloud uploads forbidden by IT policy | Local processing only, zero cloud upload |
| Trainer can't also translate | AI auto-translation + auto-narration |

### ROI estimate (mid-size GC, $30M revenue)
- Old flow (outsourced): 5 languages × 10 monthly videos = $7,000/mo + 2-week production
- New flow (IDT+ITS): $14/mo + 1-day production (30-min auto-processing)
- **Savings: $7,000/mo, $84,000/yr**

### Recommended package
- Insight Training Studio Business ($499/yr)
- Insight Doc Translator Personal ($199/yr, for written contract translation)
- **Total: $698/yr to save $84,000/yr**

### Affiliate niches
- Construction industry publications
- Construction-tech blogs / YouTube channels
- Foreign worker compliance consultants

### Sales pitch
> "With foreign worker numbers projected to keep climbing, native-language safety training is no longer optional. HARMONIC insight's Insight Training Studio takes one PowerPoint deck and produces 13-language MP4s in 30 minutes. Zero cloud upload, so it complies with even the strictest IT security policies."

---

## 2. Education (Schools & EdTech)

### Industry challenges
- **Multicultural classrooms**: Foreign students require native-language support
- **E-learning multilingualization**: English-only insufficient for international students
- **Teacher workload**: Content creation alone is overwhelming, translation untenable
- **Budget constraints**: Both public and private schools have limited translation budgets

### Why HARMONIC insight wins

| Challenge | Solution |
|-----------|----------|
| Want to deliver content in 13 languages | ITS converts PPT → multilingual MP4 |
| Distribution materials need translation | IDT translates PPTX/DOCX/XLSX |
| Teachers aren't tech-savvy | Click-only simple UI |
| Tight budget | $14/mo, API costs are usage-based |

### Recommended package
- Insight Doc Translator Personal ($199/yr)
- Insight Training Studio Personal ($199/yr)
- **Total: $398/yr**

### Affiliate niches
- Teacher-facing media
- E-learning YouTubers
- Course content production companies

### Sales pitch
> "Want to deliver e-learning content beyond English but the translation and dubbing costs are enormous? Insight Training Studio takes your existing PowerPoint and auto-generates 13-language narrated videos. At $14/month, it costs less than a single course translation."

---

## 3. Healthcare & Pharma

### Industry challenges
- **Regulatory compliance**: HIPAA, GDPR severely restrict cloud upload of medical info
- **Multilingual patient care**: Foreign patients need native-language consent forms, instructions
- **Pharma regulatory docs**: FDA, EMA, PMDA submissions require multilingual versions
- **Accuracy is critical**: Mistranslation = medical error or regulatory violation

### Why HARMONIC insight wins

| Challenge | Solution |
|-----------|----------|
| Cloud translation forbidden | **Full local processing + BYOK** |
| Specialized terminology accuracy | Engine switching (Claude/DeepL/Azure) per use case |
| Patient material multilingualization | IDT one-click, format preserved |
| Validation required | 5-engine cross-check makes human review easy |

### Recommended package
- Insight Doc Translator Business ($499/yr) — batch processing essential
- Azure OpenAI Private deployment recommended

### Affiliate niches
- Medical informatics conferences
- Healthcare consultants
- Pharma industry publications

### Sales pitch
> "How do you currently translate patient materials? Cloud translation services may violate HIPAA. Insight Doc Translator processes everything within your hospital's network, and pointed at Azure OpenAI Private deployment, even the engine sees nothing leave your tenant. Consent forms, medical records, patient education — all covered."

---

## 4. Legal Firms & Business Contracts

### Industry challenges
- **Attorney-client privilege**: Cloud upload of contracts and pleadings risks breach
- **Increasing international work**: M&A, market entry, import/export drive English contract demand
- **Accuracy and nuance**: Mistranslation in legally binding docs = liability
- **Time pressure**: Clients want same-day translation

### Why HARMONIC insight wins

| Challenge | Solution |
|-----------|----------|
| Privilege requires no cloud | Full local processing |
| Legal terminology accuracy | Claude engine for context-aware translation |
| Word format preservation | Paragraphs, footnotes, comments, indentation perfectly preserved |
| Same-day turnaround | 100-page contract draft translated in 30 min |

### Recommended package
- Insight Doc Translator Business ($499/yr)
- Claude Pro (API contract)

### Affiliate niches
- Legaltech publications
- Lawyer-focused SaaS reviewers
- International practice consultants

### Sales pitch
> "Ever hesitated before uploading a client contract to DeepL? Insight Doc Translator processes Word files within your firm's network, sending only the necessary text to your AI engine of choice (Claude recommended). Privilege intact. Word formatting perfect. 100-page contract, first-draft translated in 30 minutes."

---

## 5. Solopreneurs, Consultants & Creators

### Industry challenges
- **Multilingual client base**: International clients, clients expanding overseas
- **Cost sensitivity**: Translation agencies ($0.10-0.30/word) blow the budget
- **Time constraints**: Solo operations doing everything
- **Quality + speed**: Clients want "English version by tomorrow"

### Why HARMONIC insight wins

| Challenge | Solution |
|-----------|----------|
| Want to keep translation costs down | $14/mo + your own API usage |
| Same-day delivery | One-click translation |
| PowerPoint presentations | Format preserved, no quality loss |
| Variable monthly volume | Subscription stays fixed regardless |

### Recommended package
- Insight Doc Translator Personal ($199/yr)
- DeepL API (usage-based, ~$5-20/mo typical)

### Affiliate niches
- Solopreneur-focused tax advisors and business coaches
- Freelancer YouTubers, Substack writers
- Crowdsourcing platform media

### Sales pitch
> "Translating proposals for overseas clients used to mean expensive translation agencies. With $14/month Insight Doc Translator, you click once. Bring your own DeepL API key, pay only for what you use. 20 proposals/month? Total cost under $30. Delivered same day."
