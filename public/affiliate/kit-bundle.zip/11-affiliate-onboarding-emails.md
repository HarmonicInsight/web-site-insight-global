# Affiliate Onboarding Email Templates / アフィリエーター オンボーディング・メールテンプレ

> アフィリエーター応募・承認・素材提供の各タイミングで、HARMONIC insight 側から自動送信または手動送信するメールテンプレ集。日本語・英語両方。

---

# 🇯🇵 日本語版

## 1. 応募受付確認（自動 / 即時）

```
件名: 【HARMONIC insight】アフィリエイト応募ありがとうございます

[応募者名] 様

このたびは HARMONIC insight アフィリエイトプログラムにご応募いただき、誠にありがとうございます。

ご応募内容を確認のうえ、2営業日以内にご承認可否をご連絡いたします。

ご応募にあたっての情報:
- 応募日時: [timestamp]
- 申請プラットフォーム: [LemonSqueezy / 直接申請]
- ご紹介媒体: [チャンネル/サイトURL]

承認までの間、以下の素材集をご覧いただけます（任意）:
- アフィリエイトキット: https://github.com/HarmonicInsight/harmonic-marketing/tree/main/sales/affiliate-kit
- メディアキット: https://h-insight.jp/affiliate-kit (準備中)
- 製品ページ: https://h-insight.jp/idt / https://h-insight.jp/its

ご質問は info@h-insight.jp までお気軽にお寄せください。

HARMONIC insight アフィリエイトチーム
```

## 2. 承認通知（手動 / 営業日以内）

```
件名: 【HARMONIC insight】アフィリエイトプログラムへようこそ！

[応募者名] 様

ご応募いただいたアフィリエイトプログラムを承認いたしました。本日より販売活動を開始いただけます。

▼ アフィリエイト ダッシュボード
https://harmonic-insight.lemonsqueezy.com/affiliates/dashboard
（Globalストア用）https://harmonic-insight-global.lemonsqueezy.com/affiliates/dashboard

▼ あなた専用のリファラルリンク
[各製品の affiliate link を個別記載]

▼ コミッション条件（再掲）
- 報酬率: 20%（recurring・自動更新時も発生）
- Cookie期間: 30日
- 最低支払額: ¥7,500（JP）/ $50（Global）
- 支払サイクル: 月次（毎月15日）
- 支払方法: 銀行振込（JP）/ Wise・PayPal（Global）

▼ アフィリエイトキット（販促素材集）
GitHub: https://github.com/HarmonicInsight/harmonic-marketing/tree/main/sales/affiliate-kit

含まれるもの:
- メディアキット（会社・製品紹介）
- 競合比較表
- FAQ・反論対応集
- ヘッドライン・コピー集
- バナー画像（13種）
- ブログ記事テンプレ × 3
- YouTube動画スクリプト × 5
- ソーシャル投稿テンプレ
- 業界別ユースケース × 5業種

▼ レビュアー用無料ライセンスをご希望の方
動画レビュー・記事執筆のために本ライセンスでの動作確認が必要な場合、
件名「Reviewer license request」で info@h-insight.jp までご連絡ください。
無料の14日間延長レビュアーライセンスを発行します。

▼ 専用クーポンコードをご希望の方
あなたのチャンネル・媒体名入りの 10% OFF クーポン（例: `YT_あなたの名前10`）を
発行可能です。視聴者がコードを入力するだけで割引と20%コミッション計上が同時に発生します。
件名「Affiliate discount code request」でお問い合わせください。

▼ 質問・素材リクエスト
info@h-insight.jp（営業時間: 平日10:00-18:00、3営業日以内に返信）

販売開始の成功を心より願っております。

HARMONIC insight アフィリエイトチーム
```

## 3. 不承認通知（手動 / 営業日以内）

```
件名: 【HARMONIC insight】アフィリエイトプログラム応募について

[応募者名] 様

このたびは HARMONIC insight アフィリエイトプログラムにご応募いただき、誠にありがとうございました。

慎重に検討させていただきましたが、現時点では誠に残念ながらご応募内容ではご承認いたしかねるとの結論に至りました。

主な理由:
- [該当する理由を記載]
  - 媒体性質と弊社製品ターゲットのミスマッチ
  - 媒体規模・実績情報が確認できなかった
  - 競合製品の取り扱いと利益相反の懸念
  - その他

将来的に媒体内容や読者層が変化された際は、再度ご応募いただけます。3か月程度経過後の再応募を歓迎いたします。

ご応募いただいたお時間に深く感謝申し上げます。

HARMONIC insight アフィリエイトチーム
```

## 4. 専用クーポンコード発行通知

```
件名: 【HARMONIC insight】専用クーポンコード発行のお知らせ

[アフィリエーター名] 様

ご依頼いただいた専用クーポンコードを発行しました。

▼ クーポンコード
- JP: [YT_YOURNAME10] → ¥20,000 → ¥18,000（10% OFF）
- Global: [YT_YOURNAME10_GL] → $199 → $179.10（10% OFF）

▼ 仕様
- 有効期限: 動画公開から90日間 / 利用上限なし
- 対象商品: 全プラン（Free除く）
- アフィリエイト紐付け: 有効（コード経由でも20%コミッション計上）
- 視聴者の使い方: チェックアウト画面のクーポン欄に入力

▼ 動画ディスクリプション例
```
HARMONIC insight Insight Doc Translator
14日無料トライアル: [リファラルリンク]
チェックアウトでクーポンコード `YT_YOURNAME10` を入力で 10% OFF
```

▼ 計測
LemonSqueezy ダッシュボードで「コード経由」「リンク経由」両方の比率を確認可能です。

ご活用ください。

HARMONIC insight アフィリエイトチーム
```

## 5. レビュアー用無料ライセンス発行通知

```
件名: 【HARMONIC insight】レビュアー用ライセンスのお届け

[アフィリエーター名] 様

ご依頼いただいたレビュアー用ライセンスをお届けします。

▼ ライセンス情報
- 製品: [Insight Doc Translator / Insight Training Studio]
- プラン: Business（フル機能版）
- 有効期間: 60日間（[YYYY-MM-DD] まで）
- ライセンスキー: [LICENSE_KEY]

▼ インストール
1. https://license.h-insight.jp/download/[productCode]?lang=ja からインストーラ取得
2. アプリ起動 → ヘルプ → ライセンス画面
3. メールアドレスとライセンスキーを入力 → アクティベート

▼ レビューにあたっての配慮事項
- 客観的な評価をお願いします（不利な評価も歓迎）
- 製品の実際の挙動をベースにレビューしてください
- アフィリエイト関係の開示（「本動画/記事はアフィリエイト案件です」）を入れてください
- 価格・機能情報の正確性をご確認ください（変更されている可能性あり）

▼ プレスキット（追加素材が必要な場合）
- 製品スクリーンショット: https://github.com/HarmonicInsight/harmonic-marketing/tree/main/assets/screenshots
- ロゴ・ブランドガイド: https://github.com/HarmonicInsight/harmonic-marketing/tree/main/assets/brand
- 動画用デモPPT: ご要望に応じて提供

質問・追加素材リクエストは info@h-insight.jp まで。

HARMONIC insight アフィリエイトチーム
```

## 6. 月次パフォーマンスレポート

```
件名: 【HARMONIC insight】[YYYY年MM月] アフィリエイト実績のお知らせ

[アフィリエーター名] 様

[YYYY年MM月] のアフィリエイト実績をお知らせします。

▼ 月次サマリー
- クリック数: [X] 件
- 購入件数: [Y] 件（成約率: [Z]%）
- コミッション総額: [合計金額]
  - 内訳: Personal × [N1] = [小計1]
         Business × [N2] = [小計2]
         （Recurring分: [小計3]）

▼ 支払予定
- 振込予定額: [金額]
- 振込日: [YYYY-MM-15]
- 振込先: [登録口座]

※ 未支払い残高が最低支払額（¥7,500 / $50）を下回る場合は翌月に繰り越しとなります。

▼ パフォーマンス分析
- 最も購入につながった媒体: [動画タイトル / 記事URL]
- 最もクリックされたリンク: [リンク種別]
- コードか直リンクか: [比率]

▼ 改善提案（任意）
- [固有の提案を記載]

ご活用ありがとうございます。来月もよろしくお願いいたします。

HARMONIC insight アフィリエイトチーム
```

---

# 🇺🇸 English Version

## 1. Application Receipt (auto, instant)

```
Subject: [HARMONIC insight] Thanks for applying to our affiliate program

Hi [Applicant Name],

Thanks for applying to the HARMONIC insight affiliate program. We've received your application and will review it within 2 business days.

Application details:
- Submitted: [timestamp]
- Platform: [LemonSqueezy / Direct]
- Channel/Site: [URL]

While we review, here are some resources you can preview:
- Affiliate kit: https://github.com/HarmonicInsight/harmonic-marketing/tree/main/sales/affiliate-kit
- Media kit: https://h-insight.jp/affiliate-kit (coming soon)
- Product pages: https://h-insight.jp/idt / https://h-insight.jp/its
- English partner page: https://license.h-insight.jp/en/partners

Questions: info@h-insight.jp

— HARMONIC insight Affiliate Team
```

## 2. Approval Notice (manual, within 2 business days)

```
Subject: [HARMONIC insight] Welcome to the affiliate program!

Hi [Applicant Name],

Great news — your affiliate application is approved. You're now active and can start promoting today.

▼ Your dashboard
https://harmonic-insight-global.lemonsqueezy.com/affiliates/dashboard

▼ Your unique referral links
[Per-product affiliate links]

▼ Commission terms (recap)
- Rate: 20% (recurring on every annual renewal)
- Cookie: 30 days
- Minimum payout: $50 / ¥7,500
- Payout cycle: Monthly (15th)
- Payout methods: Wise / PayPal (Global), bank transfer (JP)

▼ Affiliate kit (sales collateral)
GitHub: https://github.com/HarmonicInsight/harmonic-marketing/tree/main/sales/affiliate-kit

Contents:
- Media kit (company / product overview)
- Competitive comparison table
- FAQ + objection handling
- Headlines and copy library
- Banner image prompts (13 designs)
- Blog post templates × 3
- YouTube scripts × 5
- Social media templates
- Industry use-case one-pagers × 5

▼ Need a reviewer license?
For review videos or blog posts, we'll issue a free 60-day reviewer license. Email info@h-insight.jp with subject "Reviewer license request".

▼ Want a custom discount code?
We can issue codes like `YT_YOURNAME10` (10% off + your 20% commission still applies). Perfect for podcasts and platforms where direct links don't work well.
Email info@h-insight.jp with subject "Affiliate discount code request".

▼ Support
info@h-insight.jp (Mon–Fri 10:00–18:00 JST, response within 1–2 business days)

Wishing you a strong launch.

— HARMONIC insight Affiliate Team
```

## 3. Rejection Notice (manual)

```
Subject: [HARMONIC insight] Update on your affiliate application

Hi [Applicant Name],

Thank you for your interest in the HARMONIC insight affiliate program. After careful review, we've decided not to approve your application at this time.

Primary reasons:
- [Specific reason]
  - Audience / product target mismatch
  - Channel size or track record could not be verified
  - Conflict of interest with competing product promotion
  - Other

If your channel content or audience evolves over time, you're welcome to reapply after 3 months. Please don't take this as a comment on the quality of your work — alignment with our specific product is the main filter.

Thanks again for considering us.

— HARMONIC insight Affiliate Team
```

## 4. Custom Discount Code Issued

```
Subject: [HARMONIC insight] Your custom discount code is ready

Hi [Affiliate Name],

Your custom discount code is now active.

▼ Code
- JP: [YT_YOURNAME10] → ¥20,000 → ¥18,000 (10% off)
- Global: [YT_YOURNAME10_GL] → $199 → $179.10 (10% off)

▼ Specs
- Validity: 90 days from video publish / unlimited use
- Eligible products: all paid plans (Free excluded)
- Affiliate attribution: enabled (commissions still tracked when buyers use code instead of link)
- How customers use it: enter in coupon field on checkout

▼ Suggested video description
```
HARMONIC insight Doc Translator
14-day free trial: [your referral link]
Use code `YT_YOURNAME10` at checkout for 10% off
```

▼ Tracking
You can see the split between code-based and link-based conversions in your LemonSqueezy dashboard.

Have a great launch.

— HARMONIC insight Affiliate Team
```

## 5. Reviewer License Issued

```
Subject: [HARMONIC insight] Your reviewer license

Hi [Affiliate Name],

Your reviewer license is ready.

▼ License Details
- Product: [Insight Doc Translator / Insight Training Studio]
- Plan: Business (full features)
- Valid until: [YYYY-MM-DD] (60 days)
- License key: [LICENSE_KEY]

▼ Install
1. Download installer: https://license.h-insight.jp/download/[productCode]?lang=en
2. Launch app → Help → License screen
3. Enter your email and the license key → Activate

▼ Review Notes
- Honest reviews welcome (including critical ones — we'd rather hear it)
- Base your review on actual product behavior in your hands
- Please disclose the affiliate relationship in the video / post
- Verify pricing and feature info before publishing (these can change)

▼ Press Kit
- Product screenshots: https://github.com/HarmonicInsight/harmonic-marketing/tree/main/assets/screenshots
- Logo / brand guide: https://github.com/HarmonicInsight/harmonic-marketing/tree/main/assets/brand
- Demo PPT (for video): available on request

Reach out for additional materials.

— HARMONIC insight Affiliate Team
```

## 6. Monthly Performance Report

```
Subject: [HARMONIC insight] Your [Month YYYY] affiliate performance

Hi [Affiliate Name],

Here's your performance summary for [Month YYYY].

▼ Monthly summary
- Clicks: [X]
- Purchases: [Y] (conversion rate: [Z]%)
- Total commission: [$ amount]
  - Personal × [N1] = [subtotal 1]
  - Business × [N2] = [subtotal 2]
  - (Recurring: [subtotal 3])

▼ Payout
- Pending: [$ amount]
- Payout date: [YYYY-MM-15]
- Method: [Wise / PayPal / bank]

* Commissions below the $50 / ¥7,500 minimum carry over to the next month.

▼ Performance highlights
- Best converting content: [video title / post URL]
- Most clicked link: [link type]
- Code vs. direct link split: [ratio]

▼ Suggestions
- [Specific recommendation]

Thanks for the great work this month.

— HARMONIC insight Affiliate Team
```
