# Resend Domain Authentication Setup / Resend ドメイン認証設定

> 海外顧客（Gmail / Outlook 等）に **迷惑メール扱いされない** ためのドメイン認証 (SPF/DKIM/DMARC) 設定ガイド。`h-insight.jp` の現状確認と必要な追加設定。

---

## 現状（2026-05-05 取得）

| レコード | 状態 | 値 |
|---------|------|------|
| **SPF** (h-insight.jp TXT) | ⚠ Resend 未追加 | `v=spf1 include:_spf.google.com ~all` |
| **DKIM** (resend._domainkey.h-insight.jp TXT) | ✅ 設定済み | `p=MIGfMA0G...wIDAQAB` (公開鍵あり) |
| **DMARC** (_dmarc.h-insight.jp TXT) | ⚠ ポリシー弱い | `v=DMARC1; p=none;` |

---

## 問題点

### A. SPF に Resend が含まれていない

現状の SPF は Google Workspace 経由の送信のみ許可。Resend 経由の送信は SPF 認証で **softfail (~all)** または **fail** になる可能性。

**結果:** Resend から送ったライセンスキーメールが Gmail/Outlook で「なりすましの疑い」マークが付く、または迷惑メール行きになる。

### B. DMARC ポリシーが `p=none`

DMARC レポートだけ送られるが、認証失敗メールに対する **強制力ゼロ**。SPF/DKIM の片方が通っていれば届く状態（DKIM が通っているので致命的ではない）が、認証強度として弱い。

---

## 修正手順

### Step 1: SPF レコード更新（DNS管理画面で）

**変更前:**
```
v=spf1 include:_spf.google.com ~all
```

**変更後:**
```
v=spf1 include:_spf.google.com include:_spf.resend.com ~all
```

> ※ Resend の正確な include 値は Resend ダッシュボード → Domains → h-insight.jp → DNS Records 画面で確認できます。一般的には `include:_spf.resend.com` ですが、Resend 側のセットアップ手順に従ってください。

**反映確認:**
```
nslookup -type=TXT h-insight.jp
# または
dig TXT h-insight.jp
```

### Step 2: DKIM 確認（既に設定済み・追加対応不要）

`resend._domainkey.h-insight.jp` に Resend の公開鍵が登録済み。確認のみ：

```
nslookup -type=TXT resend._domainkey.h-insight.jp
```

`p=MIGfMA0G...` で始まる公開鍵が返ってくれば OK。

### Step 3: DMARC ポリシー強化（段階的）

#### Phase 1（現状）: `p=none` ── レポートのみ
既に設定済み。Resend ダッシュボードで認証失敗の集計レポートを受信可能。

#### Phase 2（推奨・販売開始 30日後〜）: `p=quarantine`
認証失敗したメールを受信側の迷惑メールフォルダに振り分け。

```
v=DMARC1; p=quarantine; pct=10; rua=mailto:dmarc-report@h-insight.jp;
```

`pct=10` で 10% から徐々に強化。ホワイトリストや誤判定の影響を最小化。

#### Phase 3（販売安定後・90日〜）: `p=reject`
認証失敗したメールを完全に拒否。最強の保護レベル。

```
v=DMARC1; p=reject; rua=mailto:dmarc-report@h-insight.jp; ruf=mailto:dmarc-forensic@h-insight.jp;
```

### Step 4: BIMI (Brand Indicators for Message Identification) ── オプション

Gmail で送信者ロゴを表示できる仕組み。販売軌道に乗ったら検討。

```
default._bimi.h-insight.jp TXT "v=BIMI1; l=https://h-insight.jp/assets/brand/logo-bimi.svg;"
```

要件:
- BIMI対応SVG（特定のSVG Tiny PS仕様）
- VMC証明書（年$1,000〜程度）
- DMARC `p=quarantine` 以上

優先度低、運用が安定してから。

---

## 検証ツール

### 設定後の検証
- **MXtoolbox SuperTool**: https://mxtoolbox.com/SuperTool.aspx
- **Mail Tester**: https://www.mail-tester.com/ （実際にメール送って認証スコアを見る）
- **Resend Dashboard**: ドメインステータスが緑になるか

### 推奨スコア目標
- Mail Tester で **9.5/10 以上**
- MXtoolbox で SPF/DKIM/DMARC すべて **PASS**

---

## トラブルシューティング

### Q: SPF を変更しても認証が通らない
A: DNS 反映に 24時間程度かかる。`+1 時間以上` 待ってから再確認。TTL を短く設定しておくと検証が速い。

### Q: Resend のメールが Gmail で迷惑メール扱いされる
A: 以下を確認：
1. SPF に `include:_spf.resend.com` が入っているか
2. DKIM `resend._domainkey.h-insight.jp` が解決するか
3. メール本文に "Click here" のような怪しい文言が多くないか
4. `From:` のドメインが `h-insight.jp` で `Reply-To:` も同ドメインか
5. `LICENSE_FROM_EMAIL` の env 値が実在するメールアドレスか

### Q: 認証は通るが Outlook で迷惑メール扱いされる
A: Outlook は独自の評価指標を持つ。
1. Microsoft SNDS にドメイン登録 (https://sendersupport.olc.protection.outlook.com/snds/)
2. DMARC を `p=quarantine` 以上に
3. 初回送信ボリュームを段階的に増やす（IP warmup）

---

## 設定後のチェックリスト

- [ ] SPF に `include:_spf.resend.com` 追加
- [ ] `nslookup -type=TXT h-insight.jp` で確認、24時間後
- [ ] Resend ダッシュボードでドメイン状態が「Verified」
- [ ] Mail Tester で 9.0+ スコア
- [ ] テスト購入を JP / Global の両方で実行 → メール到達確認
- [ ] Gmail / Outlook / Yahoo Mail で迷惑メール行きにならないか確認
- [ ] DMARC ポリシーを `p=quarantine; pct=10` に上げる（販売開始30日後）

---

## 参考リンク

- Resend Setup Domain: https://resend.com/docs/dashboard/domains/introduction
- SPF Record Generator: https://www.spfwizard.net/
- DMARC Record Generator: https://dmarcian.com/dmarc-record-wizard/
- Mail Tester: https://www.mail-tester.com/
