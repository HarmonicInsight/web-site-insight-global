# Media Kit / メディアキット

> アフィリエーター・メディア向け配布資料。1〜2ページに要約された **「これだけ見れば判断できる」** 公式情報。

---

# 🇯🇵 日本語版

## 会社概要

| 項目 | 内容 |
|------|------|
| 法人名 | ハーモニックインサイト合同会社 |
| 屋号・ブランド | HARMONIC insight |
| 代表社員 | 瀬田 ルリ子 |
| 設立 | 2025年8月 |
| 所在地 | 東京都 |
| 事業内容 | Office文書 AI 処理ツールの開発・販売 |
| 問い合わせ | info@h-insight.jp |
| Webサイト | https://h-insight.jp |

## ブランドステートメント

> **「あなたのデータを、あなたのAIで、あなたのPCで処理する。」**
>
> HARMONIC insight は、Office 文書（PowerPoint、Word、Excel）の翻訳・動画化を、お客様自身の AI（DeepL / Google / Azure / Claude / Gemini）で処理する **BYOK（Bring Your Own Key）** 型の Windows ネイティブアプリを提供します。クラウドにデータを送信せず、ローカル環境で完結。法務・医療・建設・教育機関など機密文書を扱う業種に選ばれています。

## 主力製品（2製品）

### 1. Insight Doc Translator（IDT / INST）

PowerPoint・Word・Excel をワンクリックで多言語翻訳。**5つの翻訳エンジンを使い分け可能**。

- 対応形式: PPTX / DOCX / XLSX
- 対応言語: 13言語（日英中韓 + 欧州主要言語 + ベトナム・タイ等）
- 翻訳エンジン: DeepL / Google / Azure / Claude / Gemini（BYOK）
- 動作環境: Windows 10/11 64bit

| プラン | JP価格 | Global価格 | 機能 |
|--------|--------|-----------|------|
| Personal | ¥20,000/年 | $199/年 | 1台、無制限利用 |
| Business | ¥50,000/年 | $499/年 | 1台、バッチ処理（複数ファイル一括） |

### 2. Insight Training Studio（ITS / INMV）

PowerPoint スライドを多言語ナレーション付きの研修動画に自動変換。**TTS 13言語対応**。

- 対応形式: PPTX 入力 → MP4 出力
- TTS エンジン: Edge / Windows SAPI / VOICEVOX（ローカル、API不要）
- 対応言語: 13言語
- 動作環境: Windows 10/11 64bit、メモリ8GB以上

| プラン | JP価格 | Global価格 | 機能 |
|--------|--------|-----------|------|
| Personal | ¥20,000/年 | $199/年 | 1台、無制限利用 |
| Business | ¥50,000/年 | $499/年 | 1台、バッチ処理 |

## 主要ターゲット顧客

1. **建設業バックオフィス**: 多言語安全教材・外国人技能実習生研修
2. **教育機関**: 教材の多言語化・eラーニング動画制作
3. **製薬・医療**: 規制文書の翻訳（クラウド送信不可）
4. **法律事務所**: 機密文書の翻訳
5. **個人事業主・コンサル**: 提案書・報告書の多言語対応

## 競合との差別化（3点）

1. **BYOK でデータ主権を顧客に**: クラウドにアップロードせず、お客様自身の API キー経由でローカル処理
2. **Office 形式の完全保持**: 表・グラフ・コメント・書式すべてを維持して翻訳
3. **複数エンジン使い分け**: DeepL（精度）・Claude（文脈）・Google（速度）など用途別に切替可能

## アフィリエイト条件

| 項目 | 条件 |
|------|------|
| **コミッション率** | **20%**（recurring：自動更新でも継続発生） |
| **Cookie 期間** | 30日 |
| **最低支払額** | ¥7,500相当 / $50 |
| **支払サイクル** | 月次（毎月15日） |
| **支払方法** | 銀行振込（JP）/ Wise・PayPal（Global） |
| **対象商品** | 全プラン（Free 除く） |
| **承認** | 2営業日以内 |

## 報酬計算例

| 商品・プラン | 1件あたり報酬 | 月10件で | 月50件で |
|------------|--------------|---------|---------|
| Personal（¥20,000） | ¥4,000 | ¥40,000 | ¥200,000 |
| Business（¥50,000） | ¥10,000 | ¥100,000 | ¥500,000 |
| Global Personal（$199） | $39.80 | $398 | $1,990 |
| Global Business（$499） | $99.80 | $998 | $4,990 |

**recurring（継続）**: 自動更新時にも同じコミッションが発生します。

## 申込み・お問い合わせ

| 項目 | リンク |
|------|-------|
| JP アフィリエイト登録 | https://harmonic-insight.lemonsqueezy.com/affiliates |
| Global アフィリエイト登録 | https://harmonic-insight-global.lemonsqueezy.com/affiliates |
| カスタム素材依頼 | info@h-insight.jp |
| 製品サポート | support@h-insight.jp |

---

# 🇺🇸 English Version

## Company Profile

| Item | Detail |
|------|--------|
| Legal Entity | Harmonic Insight LLC (合同会社) |
| Brand | HARMONIC insight |
| Representative | Ruriko Seta |
| Founded | August 2025 |
| Location | Tokyo, Japan |
| Business | Windows-native AI tools for Office documents |
| Contact | info@h-insight.jp |
| Website | https://h-insight.jp |

## Brand Statement

> **"Your data, your AI, your PC."**
>
> HARMONIC insight builds Windows-native apps that translate Office documents (PowerPoint, Word, Excel) and turn slides into multilingual training videos — using **your own AI keys** (BYOK: DeepL / Google / Azure / Claude / Gemini). No cloud uploads. No data sent to our servers. Trusted by legal, medical, construction, and education professionals who handle sensitive documents.

## Product Lineup (2 products)

### 1. Insight Doc Translator (IDT / INST)

One-click multilingual translation for PowerPoint, Word, and Excel. **Choose from 5 translation engines.**

- Formats: PPTX / DOCX / XLSX
- Languages: 13 (EN, JA, ZH, KO, EU majors, VI, TH, etc.)
- Engines: DeepL / Google / Azure / Claude / Gemini (BYOK)
- Platform: Windows 10/11 64bit

| Plan | JP Price | Global Price | Features |
|------|----------|-------------|----------|
| Personal | ¥20,000/yr | $199/yr | 1 device, unlimited use |
| Business | ¥50,000/yr | $499/yr | 1 device, batch processing |

### 2. Insight Training Studio (ITS / INMV)

Convert PowerPoint slides into multilingual training videos with TTS narration. **13 languages supported.**

- Input: PPTX → Output: MP4
- TTS Engines: Edge / Windows SAPI / VOICEVOX (local, no API needed)
- Languages: 13
- Platform: Windows 10/11 64bit, 8GB+ RAM

| Plan | JP Price | Global Price | Features |
|------|----------|-------------|----------|
| Personal | ¥20,000/yr | $199/yr | 1 device, unlimited use |
| Business | ¥50,000/yr | $499/yr | 1 device, batch processing |

## Target Customers

1. **Construction back-office**: Multilingual safety training, foreign worker onboarding
2. **Education**: Multilingual course materials, e-learning videos
3. **Pharma & Medical**: Regulated document translation (no cloud allowed)
4. **Legal**: Confidential document translation
5. **Solopreneurs & Consultants**: Multilingual proposals and reports

## 3 Key Differentiators vs Competitors

1. **BYOK = data sovereignty**: No cloud upload — process via your own API keys
2. **Office format preserved**: Tables, charts, comments, formatting fully maintained
3. **Multi-engine flexibility**: Switch between DeepL (accuracy), Claude (context), Google (speed) per use case

## Affiliate Program

| Item | Details |
|------|---------|
| **Commission rate** | **20%** (recurring on annual renewals) |
| **Cookie window** | 30 days |
| **Minimum payout** | $50 / ¥7,500 |
| **Payment cycle** | Monthly (15th of each month) |
| **Payment methods** | Wise / PayPal (Global), bank transfer (JP) |
| **Eligible products** | All paid plans |
| **Approval** | Within 2 business days |

## Earnings Examples

| Product / Plan | Per sale | 10 sales/mo | 50 sales/mo |
|---------------|---------|-------------|-------------|
| Personal ($199) | $39.80 | $398 | $1,990 |
| Business ($499) | $99.80 | $998 | $4,990 |
| Personal (¥20,000) | ¥4,000 | ¥40,000 | ¥200,000 |
| Business (¥50,000) | ¥10,000 | ¥100,000 | ¥500,000 |

**Recurring**: Earn the same commission on each annual renewal.

## Apply / Contact

| Action | Link |
|--------|------|
| JP affiliate signup | https://harmonic-insight.lemonsqueezy.com/affiliates |
| Global affiliate signup | https://harmonic-insight-global.lemonsqueezy.com/affiliates |
| Affiliate landing page (EN) | https://license.h-insight.jp/en/partners |
| Custom asset request | info@h-insight.jp |
| Product support | support@h-insight.jp |
