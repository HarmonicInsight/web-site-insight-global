# Headlines & Copy Library / ヘッドライン・コピー集

> アフィリエーターが SNS / 記事 / 動画ディスクリプション / メールに**そのままコピペできる**コピー集。短中長の3段階 × 日英 × 製品別。

---

# 🇯🇵 日本語版

## 短ヘッドライン（30字以内）

### Insight Doc Translator
1. PowerPoint をワンクリックで多言語化
2. 機密文書もクラウド送信せずに翻訳
3. DeepL・Claude・Google を1本のアプリで
4. PPTX書式を100%保ったまま翻訳
5. BYOKで月¥1,667から始める Office翻訳
6. 翻訳5エンジンを使い分ける時代へ
7. クラウドに上げられない文書、どうしてた？
8. オフィスソフト多言語化を5分で完結
9. 提案書、英訳に1日かけてませんか
10. AIキー1本で5社の翻訳を選べる

### Insight Training Studio
1. PPT を13言語の研修動画に自動変換
2. eラーニング教材を5分で多言語化
3. 外国人向け安全教育動画を量産
4. ナレーション収録なしで研修動画
5. PowerPoint だけで動画コンテンツ完成
6. 13言語TTSで研修動画を一気に展開
7. 海外子会社向け教育を内製化
8. PPT→MP4変換に時間を使うのは終わり
9. スライドが多言語動画になる時代
10. 人件費ゼロで研修動画を作る方法

## 中ヘッドライン（100字以内）

### Insight Doc Translator
1. クラウド送信できない機密文書も、自分のAPIキーで安全に翻訳できる Windows ネイティブアプリ。DeepL・Claude・Google・Azure・Gemini の5エンジンを使い分け可能。月¥1,667から。

2. PowerPoint・Word・Excel をワンクリックで多言語化。表・グラフ・コメント・数式まで完全保持。13言語対応。法務・医療・建設の機密文書翻訳に最適。

3. 「DeepL は使いたい、でもクラウド送信は規定上NG」を解決する BYOK 型 Office 翻訳ツール。HARMONIC insight のサーバーには一切データが送信されません。

### Insight Training Studio
1. 既存の PowerPoint スライドを、13言語のナレーション付き研修動画に自動変換。クラウド送信なし、ローカルTTSで完結。eラーニング教材の量産が5分で可能に。

2. 多言語の研修動画を、ナレーション収録なし・編集ソフト不要で量産。外国人作業員向け安全教材、海外子会社向け社内教育、製品マニュアル動画に最適。

3. PowerPoint を入れたら 13言語の MP4 が出てくる。それだけ。研修コンテンツの多言語化に毎月かけていた時間とコストを、今すぐゼロに。

## 長ヘッドライン（200〜500字）

### Insight Doc Translator（ブログ・LinkedIn 投稿向け）

**「翻訳の精度より、データを送信しない方が大事」── そんな業種は意外と多い**

医療法人、法律事務所、建設業のISO規定、金融機関のコンプライアンス。これらの業種では「クラウド翻訳サービスを使うこと自体が NG」というケースが珍しくありません。

私たちが作った Insight Doc Translator は、お客様自身が DeepL や Claude のアカウントを契約して取得した API キーを、Windows ネイティブのアプリに登録するだけ。ファイルは**お客様の PC 内で処理され**、必要な部分だけお客様の API キー経由で翻訳エンジンに送信されます。

HARMONIC insight 側のサーバーには**一切データが送信されません**。翻訳エンジン側との関係は、お客様自身が選んだ事業者の規約に従うため、Azure OpenAI のプライベート環境などにも切り替え可能。

PowerPoint・Word・Excel の書式（表・グラフ・コメント・数式）を完全保持して 13言語に翻訳できます。月 ¥1,667 から。14日間無料トライアル付き。

### Insight Training Studio（YouTubeディスクリプション向け）

**研修コンテンツの多言語化、毎月どれくらい時間かけてますか？**

PPT を作って、ナレーターに依頼して、収録して、編集して、字幕入れて……。これを 5言語 × 月10本やると、コンテンツ制作チームは他のことができなくなります。

Insight Training Studio は、PowerPoint スライドの台本ノートを読み上げて、13言語の MP4 動画を**自動生成**します。Microsoft Edge の TTS、Windows 標準 SAPI、フリーの VOICEVOX が使えるので、API 課金もありません。完全ローカル動作なのでクラウド送信もなし。

外国人技能実習生向けの安全教材、海外子会社向けの新人研修、製品マニュアル動画。**これまで「人手で作るしかない」と思っていた多言語コンテンツが、今後は PowerPoint を編集するだけで増産できます**。

月 ¥1,667 から。Pro 版なら無制限。Business 版なら一括バッチで複数言語版を一気に出力。

## SNS 投稿テンプレ

### X / Twitter（140文字以内）

```
DeepLの精度は欲しい。でもクラウドにアップロードできない文書がある。

そんなときの選択肢が増えた。Insight Doc Translatorは、自分のAPIキーで5エンジンの翻訳を使い分け。データは自分のPC内で処理。月1,667円。
https://h-insight.jp/idt
```

```
PPTを13言語の研修動画にする時代。

ナレーション収録ゼロ。クラウド送信ゼロ。Insight Training Studioでスライドが MP4 に変わる。

外国人向け安全教育の量産に。
https://h-insight.jp/its
```

```
法律事務所の友人「翻訳サービス使えないんだよ、規定で」

私「じゃあBYOKでDeepLを呼ぶアプリは？」

友人「え、そんなのあるの」

ありますHARMONIC insight の Insight Doc Translator
https://h-insight.jp/idt
```

### LinkedIn（短）

```
**機密文書の翻訳、こうしてます**

医療・法律・建設で「クラウド翻訳禁止」の規定がある場合、長く悩んでいたのが Office文書の多言語化。

最近導入した HARMONIC insight の Insight Doc Translator は、自分のDeepL APIキーを Windows アプリに登録するだけで PPTX/DOCX/XLSX をワンクリック翻訳。データは PC 内で処理されるので規定違反にならない。

似た悩みのある方、参考まで。
```

### LinkedIn（長）

```
**外国人技能実習生向け安全教育、コンテンツ制作の負担を1/10にした方法**

建設業バックオフィスの方、どうやって多言語の安全教材を作ってますか？うちは月10本作ってますが、長らく以下のフローでした：

1. 日本語スライド作成（1日）
2. 各言語に翻訳（半日 × 5言語）
3. ナレーター手配・収録（2日）
4. 動画編集・字幕入れ（2日）

合計 1.5週間。担当者2名フル稼働。

Insight Training Studio を導入してから：

1. 日本語スライド作成（1日）
2. アプリで13言語版MP4を一括生成（30分）

これだけ。

PowerPoint のスピーカーノート部分を AI が読み上げ、TTS は完全ローカル動作なので API 料金もゼロ。クラウド送信ゼロなので会社の規定にも準拠。

月 ¥1,667 のサブスクで、月の人件費を100時間以上節約できてます。

似た課題の方、参考まで。
```

---

# 🇺🇸 English Version

## Short Headlines (under 60 chars)

### Insight Doc Translator
1. Translate PowerPoint without cloud upload
2. 5 translation engines, one app. BYOK.
3. Office format perfect. Translation perfect.
4. The translator that doesn't upload your docs
5. Your DeepL key, your PowerPoint, no middleman
6. $199/yr — DeepL Pro plus 4 more engines
7. Translate confidential docs the IT-approved way
8. PPTX in, multilingual PPTX out. Local.
9. The 5-engine Office translator
10. Built for documents your cloud can't see

### Insight Training Studio
1. PowerPoint to multilingual video, 5 minutes
2. 13-language training videos from your slides
3. No narrator. No cloud. Just slides → video.
4. Scale L&D content 13x without a video team
5. Train foreign workers in their language
6. Multilingual video, zero recording
7. PPT → MP4 in 13 languages, automatically
8. Stop recording. Start generating.
9. Slides become videos. Locally.
10. Internal training, multilingual, automated

## Medium Headlines (under 200 chars)

### Insight Doc Translator

1. Windows-native Office translator that uses **your own** DeepL/Claude/Google/Azure/Gemini API key. Translates PPTX/DOCX/XLSX with perfect format preservation. No data ever uploaded to our servers. $199/yr.

2. The translator built for industries where cloud upload is forbidden — healthcare, legal, construction, defense. Same DeepL quality you love, but the file processing happens on your PC.

3. DeepL Pro is great until you can't upload. Insight Doc Translator lets you use DeepL (or Claude, Google, Azure, Gemini) on documents that can't leave your network. BYOK. Local processing. $199/yr.

### Insight Training Studio

1. Convert your PowerPoint into 13-language training videos. Local TTS, no cloud, no recording, no editing. Built for L&D teams scaling multilingual e-learning content.

2. PPTX in. Multilingual MP4 out. That's it. Replace weeks of voice recording and video editing with a 5-minute automated pipeline. Perfect for foreign worker training and overseas subsidiary education.

3. The training video tool that thinks like an L&D manager: works directly from your existing PowerPoint, outputs 13 languages in batch, runs entirely on your laptop, costs $199/year.

## Long Form (300-500 words for blog/LinkedIn)

### Insight Doc Translator (LinkedIn / blog)

**"Translation accuracy matters less than not uploading the doc" — and that describes more industries than you'd think**

Healthcare, legal, construction (ISO compliance), finance — many industries flat-out prohibit cloud translation services. "We can't use DeepL" isn't a preference; it's compliance.

We built Insight Doc Translator for exactly this case. You sign up with DeepL (or Claude, Google, Azure, Gemini) and get your own API key. Drop the key into the Windows app, and **the file processing happens entirely on your PC**. The only thing leaving your network is the specific text being translated, sent through **your own** key to **your chosen** provider.

HARMONIC insight servers? They never see your data. Period.

For the most sensitive workflows, point Insight Doc Translator at an on-prem Azure OpenAI deployment in your tenant. Now even the engine sees nothing leave your environment.

PowerPoint, Word, Excel — full format preservation including tables, charts, comments, and formulas. 13 languages. $199/yr Personal, $499/yr Business with batch processing. 14-day free trial.

### Insight Training Studio (YouTube description / blog)

**How much time does your L&D team spend on multilingual content?**

The traditional pipeline:
1. Build the PowerPoint deck (1 day)
2. Get it translated (half-day per language)
3. Record narration with native speakers (2 days)
4. Edit video, add subtitles (2 days)
5. Repeat for each language

For 5 languages, that's 1.5 weeks of two people, fully booked. Every month.

Insight Training Studio does this differently:

1. Build the PowerPoint deck (1 day)
2. Run it through Insight Training Studio → 13 multilingual MP4s in 30 minutes

That's it.

The app reads PowerPoint speaker notes, translates them via your AI engine of choice, generates TTS narration locally (Edge TTS, Windows SAPI, or VOICEVOX — no API costs, no cloud upload), and renders MP4 videos with synced narration.

Foreign worker safety training. Overseas subsidiary onboarding. Product manual videos. Anything that fits the "PowerPoint → multilingual video" pattern.

$199/year Personal. $499/year Business with batch output. Built for Windows. Try free for 14 days.

## Social Post Templates

### Twitter / X (under 280 chars)

```
DeepL Pro is great. But sometimes you can't upload to the cloud (medical, legal, construction).

@HARMONICinsight's Doc Translator lets you use DeepL with your own API key — files stay on your PC. $199/yr.

https://license.h-insight.jp/en/partners
```

```
PowerPoint → MP4 in 13 languages, automatically. No narrator, no cloud, no editing.

We replaced our 1.5-week multilingual video pipeline with a 30-minute one using Insight Training Studio. $199/yr.

#elearning #L&D
```

```
Friend at a law firm: "Can't use translation services. Compliance."

Me: "What about an app that runs DeepL locally with your own API key?"

Friend: "Wait, that exists?"

It does. @HARMONICinsight Doc Translator.
```

### LinkedIn (short)

```
**How we handle confidential document translation**

Medical, legal, construction — many industries forbid cloud translation services for compliance reasons. Office document multilingualization has been a real pain point.

We recently adopted HARMONIC insight's Doc Translator: you register your own DeepL API key in a Windows app, and PPTX/DOCX/XLSX files get translated with one click. Files stay on the PC, no compliance violations.

Sharing for anyone facing the same constraint.
```

### LinkedIn (long)

```
**How we cut multilingual L&D content production by 10x**

Construction back-office teams: how do you produce safety training in foreign workers' languages? We were producing 10 videos/month with this flow:

1. Japanese slides (1 day)
2. Translate to 5 languages (half-day each)
3. Hire narrators, record (2 days)
4. Edit videos, add subtitles (2 days)

= 1.5 weeks, 2 people fully booked, every month.

After adopting Insight Training Studio:

1. Japanese slides (1 day)
2. Generate all 13 language MP4s automatically (30 minutes)

That's it.

The app reads speaker notes, translates them, generates narration with local TTS (no API costs, no cloud upload — perfect for our compliance), and outputs ready-to-use MP4s.

$199/year subscription, saving us 100+ person-hours per month.

Sharing for anyone working through similar L&D scaling problems.
```

## Email Newsletter Snippets

### 3-line snippet
> One tool I'm using: **Insight Doc Translator** lets you translate PowerPoint files using your own DeepL/Claude/Google API key — meaning the files never leave your PC. $199/yr. Built for confidential workflows. [Link with affiliate code]

### 5-line snippet
> If you've ever needed to translate confidential Office documents but couldn't use cloud services for compliance reasons, **Insight Doc Translator** solves exactly that. It's a Windows app that runs translation engines (DeepL, Claude, etc.) via your own API key, processing files locally. PowerPoint formatting is preserved perfectly. $199/yr Personal, $499/yr Business with batch processing. 14-day free trial. [Link]

### 10-line snippet
> **Tool of the week: Insight Doc Translator**
>
> If your industry forbids cloud translation (healthcare, legal, construction compliance, finance), this Windows app is built for you.
>
> You bring your own API key (DeepL, Claude, Google, Azure, or Gemini). The app processes files **on your PC** — only the text being translated is sent through your key to your chosen provider. HARMONIC insight servers never see your data.
>
> PowerPoint, Word, Excel — formatting preserved perfectly. 13 languages. $199/year Personal plan. 14-day free trial.
>
> Disclosure: affiliate link. [Link]
