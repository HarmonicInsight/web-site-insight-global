# HARMONIC insight Affiliate Kit / アフィリエイトキット

国内外のアフィリエーター・パートナーが HARMONIC insight 4製品を**自信をもって販売**するための公式素材集。日本語と英語の両方を提供。

## 配布物一覧

| # | ファイル | 内容 | 言語 |
|---|---------|------|------|
| 01 | `01-media-kit.md` | メディアキット（会社・製品・コミッション概要） | 日英 |
| 02 | `02-comparison-table.md` | 競合比較表（vs DeepL Pro / Google翻訳 / Office365） | 日英 |
| 03 | `03-faq-objections.md` | よくある質問・反論対応集 | 日英 |
| 04 | `04-headlines-copy.md` | ヘッドライン・コピー集（短中長 × 2製品） | 日英 |
| 05 | `05-banner-prompts.json` | ヒーローバナー AI 生成プロンプト集（`tools/ai-image-gen/generate.py` 入力用） | — |
| 06 | `06-blog-posts.md` | ブログ寄稿テンプレ × 3本 | 日英 |
| 07 | `07-youtube-scripts.md` | YouTube動画スクリプト × 5本 | 日英 |
| 08 | `08-newsletter-snippets.md` | ニュースレター挿入テンプレ | 日英 |
| 09 | `09-usecase-onepagers.md` | 業界別ユースケース1ページ × 5業界 | 日英 |
| 10 | `10-social-templates.md` | ソーシャル投稿テンプレ（X / LinkedIn / Facebook） | 日英 |
| 11 | `11-affiliate-onboarding-emails.md` | アフィリエーター応募〜実績報告までのメールテンプレ集 | 日英 |
| 12 | `12-ls-dashboard-checklist.md` | LSダッシュボード設定チェックリスト（運営側手動作業） | 日英 |
| 13 | `13-resend-dns-setup.md` | Resendドメイン認証 (SPF/DKIM/DMARC) 設定ガイド | 日 |
| 14-24 | [`extras-jp/`](./extras-jp/) | **JA 限定 運用補助素材**：プレイブック・ペルソナ・報酬計算・30日 SNS カレンダー・コールドメール・業界深掘り 4 業界・追加ブログ 10 本 | 日 |
| — | [`videos/`](./videos/) | **製品動画素材**：INMV/INST のフル動画 3 本（A 機能版 + B 物語版）・縦 Shorts 2 本・短尺 GIF/MP4 クリップ 5 シーン | — |
| — | `pdf/*.pdf` | 主要素材のPDF版（メディアキット・比較表・FAQ・ オンボーディングメール・LSチェックリスト・README） | 日英 |
| — | `../../assets/brand/logo-harmonic-insight.svg` | ブランドロゴ（暫定版・SVG・navy/white 2バリアント） | — |
| — | `../../assets/brand/banner-templates.html` | ヒーローバナーHTMLテンプレ（11種・ブラウザでスクショ可能） | 日英 |
| — | `web-site-insight-global/public/affiliate/banners/` | **既に生成済みバナー画像 32 種**（INMV/INST × 5 サイズ × 4 訴求軸：emotional/outcome/comparison/testimonial）| 日英 |

## 製品ラインナップ

| 製品 | コード | Personal | Business |
|------|-------|----------|----------|
| Insight Doc Translator（IDT） | INST | ¥20,000 / $199 | ¥50,000 / $499 |
| Insight Training Studio（ITS） | INMV | ¥20,000 / $199 | ¥50,000 / $499 |

## アフィリエイト条件

- **コミッション率: 20%**（Personal $39.80 / Business $99.80・recurring）
- **Cookie期間: 30日**
- **最低支払額: $50（Globalストア） / ¥7,500（JPストア）**
- **支払方法: Wise / PayPal（Global）/ 銀行振込（JP）**

## アフィリエイト申込み窓口

| ストア | 申込みURL |
|-------|----------|
| JPストア（円） | https://harmonic-insight.lemonsqueezy.com/affiliates |
| Globalストア（USD） | https://harmonic-insight-global.lemonsqueezy.com/affiliates |

承認は通常2営業日以内。

## ブランド表記ルール（必須）

- 正式名称: **HARMONIC insight**（HARMONIC は大文字、insight は小文字、半角スペース1個）
- ❌ 誤記NG: `Harmonic Insight`, `HARMONIC Insight`, `harmonic insight`, `Harmonic-Insight`

## ロゴ・ブランドカラー

- ゴールド: `#C9A249`
- アイボリー: `#FAF8F5`
- 紺: `#1a1a2e`

ロゴファイル（PNG/SVG）は `assets/brand/` から取得（要追加）。

## アフィリエイター個別の素材リクエスト

以下が必要な場合は `info@h-insight.jp` に連絡：
- カスタム割引コード（例: `YT_YOURNAME10` で 10% OFF + 20% コミッション）
- レビュアー用無料ライセンス
- カスタム LP（あなたの名前入りランディング）
- 専用バナー（あなたのチャンネル名入り）
- インタビュー対応（製品開発者の声）

## 動画素材の場所

製品個別の動画は本キット内の **[`videos/`](./videos/)** にあります：

| ファイル | 製品 | 尺 | サイズ | ナレーション | 用途 |
|---|---|---|---|---|---|
| `full_INMV_A_features_60s.mp4` | INMV | 約 2 分 | 32.5 MB | 男性・機能カタログ | YouTube・ブログ・商談 |
| `full_INMV_B_story_60s.mp4` | INMV | 約 2 分 | 35.4 MB | 女性・物語（松本さん視点）| SNS 拡散・感情訴求 |
| `full_INST_A_features_60s.mp4` | INST | 約 2 分 | 20.6 MB | 男性・機能カタログ | YouTube・ブログ・商談 |
| `full_INST_B_story_60s.mp4` | INST | 約 2 分 | 32.3 MB | 女性・物語（田中・グエン視点）| SNS 拡散・感情訴求 |
| `INMV_shorts_30s_vertical.mp4` | INMV | 30 秒 | 7.2 MB | あり | TikTok / Reels / Shorts |
| `INST_shorts_30s_vertical.mp4` | INST | 30 秒 | 4.8 MB | あり | TikTok / Reels / Shorts |
| `INST_B_shorts_30s_vertical.mp4` | INST | 30 秒 | 7.3 MB | あり（女性物語）| TikTok / Reels / Shorts |
| `clips/clip*.mp4` / `.gif` × 5 | INMV | 8〜14 秒 | 各 2〜3 MB | なし（autoplay muted 用） | 記事内自動再生・GIF 添付 |

**ブランド動画**（15 秒・30 秒・90 秒の各種）は `../web-site-insight-global/public/video/` にあります（insightoffice.io にデプロイ済み）。

### 重要：物語版動画（B 版）の使用上の注意

`full_INMV_B_story_60s.mp4` / `full_INST_B_story_60s.mp4` の登場人物（松本さん・田中さん・グエンさん）は **架空のモデルケース** です。実際のパイロット運用と機能仕様にもとづいて再構成しています。

- ✅ そのまま使ってよい用途：自社サイト埋め込み、SNS 拡散、商談デモ、ブログ挿入
- ⚠️ 補足を強く推奨：「※登場人物は架空のモデルケースです」を概要欄・キャプションに必ず併記
- ❌ NG：「導入企業の声」「実際の顧客」と表現すること
- 実顧客事例（顔出し OK 1 社獲得後）を作る場合は、本キット v2 で差し替え予定

YouTube スクリプト（5 本）は `07-youtube-scripts.md` を参照。
B-roll 映像が必要な場合は `info@h-insight.jp` に連絡。

## このキット自体について

本キットは **2026-05-05 初版**。最新版は GitHub `harmonic-marketing/sales/affiliate-kit/` で確認できます。

質問・素材リクエスト・新規アフィリエーター登録は `info@h-insight.jp` まで。
