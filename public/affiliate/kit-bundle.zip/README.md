# HARMONIC insight — Official Affiliate Kit
============================================================

Everything an approved affiliate needs in one place.
Source-of-truth for company facts, comparison tables, FAQs, copy, scripts,
and templates. Reuse, remix, customize.

## Files

01-media-kit         — Company profile, products, brand statement, terms (md + pdf)
02-comparison-table  — vs DeepL / Google / M365 / Camtasia / Synthesia (md + pdf)
03-faq-objections    — 18 Q&As with objection-handling, JP+EN (md + pdf)
04-headlines-copy    — Pre-approved headlines for banners, blog, social (md)
05-banner-prompts    — AI image generation prompts for hero banners (json)
06-blog-posts        — Drop-in blog post templates (md)
07-youtube-scripts   — Video scripts (md)
08-newsletter-snippets — Email newsletter copy chunks (md)
09-usecase-onepagers — Industry-specific one-pagers (md)
10-social-templates  — X / LinkedIn / Note post templates (md)
11-affiliate-onboarding-emails — Sequence for your subscribers (md + pdf)

## License & usage

- Reuse this material in your blog, video, newsletter, podcast, or
  paid ads as long as you're an approved affiliate
- Don't bid on our brand keywords (HARMONIC insight, Insight Doc Translator,
  Insight Training Studio, insightoffice.io)
- Don't claim absolute superiority ("best translator ever", "100% accurate")
- Always disclose the affiliate relationship per FTC / ASA / 景表法
- Custom assets, exclusive coupon codes, and co-marketing requests:
  affiliates@h-insight.jp

## Updates

This bundle is regenerated whenever the source files in
`harmonic-marketing/sales/affiliate-kit/` change. The version date is the
ZIP file's modified timestamp.

============================================================
HARMONIC insight LLC · Tokyo · insightoffice.io · founded August 2025
