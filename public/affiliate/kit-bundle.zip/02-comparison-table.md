# Comparison Table / 競合比較表

> アフィリエーターが「他のツールと何が違うのか」を 30秒で説明できる素材。記事・動画・ピッチに直接コピペできる形式で提供。

---

# 🇯🇵 日本語版

## Insight Doc Translator vs 競合（一覧）

| 項目 | **Insight Doc Translator** | DeepL Pro | Google翻訳 | Microsoft 365 Translator |
|------|:--------------------------:|:---------:|:---------:|:------------------------:|
| **対応形式** | PPTX / DOCX / XLSX | PDF / DOCX / PPTX 中心 | テキスト中心 | DOCX / PPTX |
| **書式維持** | ✅ 完全維持（表・図・コメント・数式） | ✅ 高品質 | ⚠ 崩れやすい | ⚠ 部分的 |
| **データ送信先** | **送信なし**（自PC内処理） | DeepL社サーバー | Googleサーバー | Microsoftサーバー |
| **BYOK（自分のAPI使用）** | ✅ 5エンジン選択可 | ❌ DeepL固定 | ❌ Google固定 | ❌ Microsoft固定 |
| **オフライン処理** | ✅ 一部可能（VOICEVOX等） | ❌ | ❌ | ❌ |
| **バッチ処理** | ✅（Business版） | ⚠ API契約必須 | ⚠ API契約必須 | ❌ |
| **価格（年額）** | ¥20,000〜（個人） | ¥1,300/月〜（年¥15,600） | 文字数課金 | M365に同梱 |
| **業務用機密文書** | ✅ ローカル処理 | ⚠ クラウド | ⚠ クラウド | ⚠ クラウド |
| **インストール** | Windows ネイティブ | Windows / Mac / Web | Web | Office内蔵 |

## 「BYOKだから安全」とはどういう意味か

通常の翻訳サービスは、お客様の文書をサービス提供者のサーバーに送信して翻訳します。これだとクラウドアップロードが法令上禁止されている業種（医療・金融・建設のISO規定等）では使えません。

**Insight Doc Translator は BYOK 方式**: お客様自身が DeepL や Claude などのアカウントを契約し、API キーを発行。アプリはお客様の PC 上でファイルを処理し、必要な部分だけ API キー経由で翻訳エンジンを呼び出します。

- **HARMONIC insight のサーバーには一切データが送信されません**
- 翻訳エンジン側のデータ取扱いは、お客様自身が選んだ事業者の規約（DeepL Pro 等のエンタープライズ規約）が適用されます
- 機密度に応じて、ローカル動作の Azure OpenAI / オンプレミス LLM などに切り替えることも可能

## Insight Training Studio vs 競合

| 項目 | **Insight Training Studio** | Camtasia | Adobe Premiere | Synthesia |
|------|:---------------------------:|:--------:|:--------------:|:---------:|
| **目的特化** | スライド→多言語動画 | 汎用動画編集 | プロ動画編集 | AIアバター動画 |
| **入力** | PPTX をそのまま | 画面録画 + 編集 | 素材組み合わせ | テキスト |
| **多言語TTS** | ✅ 13言語、自動切替 | ⚠ 別途音声収録 | ⚠ 別途音声収録 | ✅ |
| **学習コスト** | 5分（既存PPTから自動） | 数時間 | 数十時間 | 1時間 |
| **API不要** | ✅ ローカルTTS可 | — | — | ❌ クラウド必須 |
| **価格** | ¥20,000/年 | $300〜（買切） | サブスク $20+/月 | $30〜/月 |
| **バッチ処理** | ✅（複数言語版を一括生成） | ❌ | ❌ | ❌ |
| **クラウド送信** | なし | なし | なし | あり |

## こういう人にオススメ（営業トーク用）

### Insight Doc Translator のターゲット

- 📄 **クライアントへの提案書を多言語で送りたい個人事業主・コンサル**
- 🏥 **医療法人で、患者向け説明文書を多言語化したい医療事務**
- 🏗️ **建設業で、外国人技能実習生向けの安全教材を多言語化したい現場監督**
- 📚 **教育機関で、教材を多言語化したい教員**
- ⚖️ **法律事務所で、契約書・準備書面を翻訳したい弁護士**

### Insight Training Studio のターゲット

- 🎓 **eラーニング教材を多言語で展開したい研修担当**
- 🏗️ **外国人作業員向けの安全教育動画を作りたい元請け**
- 🌐 **製品マニュアル動画を13言語で配信したいメーカー**
- 📺 **YouTubeに英語版を出したい日本のクリエイター**
- 💼 **海外子会社向けの社内教育動画を量産したい本社研修部**

---

# 🇺🇸 English Version

## Insight Doc Translator vs Competitors

| Item | **Insight Doc Translator** | DeepL Pro | Google Translate | M365 Translator |
|------|:--------------------------:|:---------:|:----------------:|:---------------:|
| **File formats** | PPTX / DOCX / XLSX | PDF / DOCX / PPTX | Text-focused | DOCX / PPTX |
| **Format preservation** | ✅ Full (tables, charts, comments, formulas) | ✅ High quality | ⚠ Often breaks | ⚠ Partial |
| **Data destination** | **No transmission** (local) | DeepL servers | Google servers | Microsoft servers |
| **BYOK (your API key)** | ✅ 5 engines selectable | ❌ DeepL only | ❌ Google only | ❌ Microsoft only |
| **Offline processing** | ✅ Partially | ❌ | ❌ | ❌ |
| **Batch processing** | ✅ (Business) | ⚠ Needs API plan | ⚠ Needs API plan | ❌ |
| **Annual cost** | $199 (Personal) | $90/yr Pro | Per-character | Bundled w/ M365 |
| **Confidential docs** | ✅ Local processing | ⚠ Cloud | ⚠ Cloud | ⚠ Cloud |
| **Install** | Windows-native | Win/Mac/Web | Web | Embedded in Office |

## What "BYOK = secure" actually means

Standard translation services upload your document to their servers. This is unworkable for industries with cloud restrictions (HIPAA in healthcare, GDPR for some EU sectors, ISO compliance in construction).

**Insight Doc Translator uses BYOK**: You sign up with DeepL, Claude, etc. directly and get your own API key. Our app processes files on **your PC**, calling the translation engine only via your key.

- **No data is sent to HARMONIC insight servers, ever.**
- Data handling is governed by your contract with the engine provider (DeepL Pro Enterprise, Azure private deployment, etc.)
- For maximum sensitivity, point IDT at on-prem LLMs or Azure OpenAI in your tenant.

## Insight Training Studio vs Competitors

| Item | **Insight Training Studio** | Camtasia | Adobe Premiere | Synthesia |
|------|:---------------------------:|:--------:|:--------------:|:---------:|
| **Purpose** | Slides → multilingual video | General video editing | Pro video editing | AI avatar video |
| **Input** | PPTX as-is | Screen capture + edit | Asset assembly | Text script |
| **Multilingual TTS** | ✅ 13 languages auto | ⚠ Record separately | ⚠ Record separately | ✅ |
| **Learning curve** | 5 min (auto from PPT) | Hours | Tens of hours | ~1 hour |
| **No-API option** | ✅ Local TTS | — | — | ❌ Cloud required |
| **Cost** | $199/year | $300 (one-time) | $20+/mo subscription | $30+/mo |
| **Batch processing** | ✅ (multiple language outputs at once) | ❌ | ❌ | ❌ |
| **Cloud upload** | None | None | None | Yes |

## Ideal customer profiles

### Insight Doc Translator

- 📄 **Solopreneurs & consultants** who send proposals to multilingual clients
- 🏥 **Healthcare admins** translating patient documents
- 🏗️ **Construction managers** training foreign workers safely
- 📚 **Educators** localizing course materials
- ⚖️ **Lawyers** translating contracts and pleadings

### Insight Training Studio

- 🎓 **L&D teams** rolling out multilingual e-learning
- 🏗️ **General contractors** producing multilingual safety videos
- 🌐 **Manufacturers** distributing product manual videos in 13 languages
- 📺 **Japanese YouTubers** wanting English versions of their content
- 💼 **HQ training departments** scaling content to overseas subsidiaries

## 30-second elevator pitch (for video / podcast affiliates)

> "DeepL is great when you can upload to the cloud. But what if your documents are confidential — medical records, legal contracts, construction safety reports? HARMONIC insight's Doc Translator does the translation on **your** PC, using **your own** API keys. Same engines. Same quality. But no cloud upload. Plus it preserves Office formatting perfectly. $199 a year."
