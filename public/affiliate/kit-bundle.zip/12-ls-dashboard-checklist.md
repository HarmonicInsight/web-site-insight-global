# LemonSqueezy Dashboard Setup Checklist / LSダッシュボード設定チェックリスト

> ユーザー（HARMONIC insight 運営側）が LS ダッシュボードで**手動設定**すべき項目のチェックリスト。コードと環境変数は揃っているので、残るのはダッシュボード側のスイッチ操作。

---

## 🇯🇵 日本語版

### A. JPストア（`harmonic-insight.lemonsqueezy.com`）

#### A-1. Webhooks 設定

`Settings → Webhooks` で確認：

- [ ] **エンドポイント URL**: `https://license.h-insight.jp/api/webhook/lemonsqueezy`
- [ ] **Signing Secret**: 設定済み（Vercelの `LEMONSQUEEZY_WEBHOOK_SECRET` と同一値）
- [ ] **対象イベント（全6つ選択）**:
  - [ ] `order_created` ← 新規購入時のライセンス発行
  - [ ] `subscription_payment_success` ← 自動更新時の expires_at 延長（**特に重要**）
  - [ ] `subscription_cancelled` ← 解約予約時のnotes追記
  - [ ] `subscription_expired` ← 期限切れ時のnotes追記
  - [ ] `subscription_payment_failed` ← 決済失敗時の即時失効
  - [ ] `order_refunded` ← 返金時の即時失効

#### A-2. 商品（Products）

`Store → Products` で確認：

- [ ] Insight Doc Translator – Personal: ¥20,000/年, Published
- [ ] Insight Doc Translator – Business: ¥50,000/年, Published
- [ ] Insight Training Studio – Personal: ¥20,000/年, Published
- [ ] Insight Training Studio – Business: ¥50,000/年, Published
- [ ] 商品名・説明文が**日本語**で登録されている
- [ ] チェックアウトURLが `?locale=ja` 付きでLPに設置されている

#### A-3. アフィリエイト機能

`Affiliates → Settings`:

- [ ] **Affiliate program: ON**
- [ ] **Default commission: 20%**
- [ ] **Cookie window: 30 days**
- [ ] **Minimum payout: ¥7,500**
- [ ] **Approval mode: Manual**（応募内容を確認してから承認）
- [ ] **Public affiliate signup page**: 有効（`harmonic-insight.lemonsqueezy.com/affiliates`）

#### A-4. Email Templates

`Settings → Emails`:

- [ ] Order Confirmation を**日本語**に置き換え
- [ ] License Key Delivery を**日本語**に置き換え
- [ ] Subscription Renewal を**日本語**に置き換え
- [ ] Payment Failed を**日本語**に置き換え

テンプレ本文は `sales/lemonsqueezy-setup.md` の「日本語ローカライゼーション Step 3」参照。

#### A-5. Store Settings

- [ ] **Brand color**: ゴールド `#C9A249`
- [ ] **Logo**: HARMONIC insight ロゴ（`assets/brand/logo-harmonic-insight.svg` か PNG変換版）
- [ ] **Currency**: JPY
- [ ] **Tax mode**: Inclusive（内税表示、価格に消費税含む）
- [ ] **Checkout language**: Japanese (auto when `?locale=ja`)
- [ ] **Footer link**: 特商法表記 `https://h-insight.jp/legal/tokushoho`
- [ ] **Activate your store**: 完了（ライブ決済可能）

---

### B. Globalストア（`harmonic-insight-global.lemonsqueezy.com`）

#### B-1. Webhooks 設定

- [ ] **エンドポイント URL**: `https://license.h-insight.jp/api/webhook/lemonsqueezy/global`
- [ ] **Signing Secret**: JPストアと**同一値**（コードのfallbackで動作）
- [ ] **対象イベント**: JPと同じ6つ全選択（A-1 と同じ）

#### B-2. 商品

- [ ] Insight Doc Translator – Personal (Global): $199/年, **Published**
- [ ] Insight Doc Translator – Business (Global): $499/年, **Draft → Publish に変更**
- [ ] Insight Training Studio – Personal (Global): $199/年, Published
- [ ] Insight Training Studio – Business (Global): $499/年, Published
- [ ] 商品名・説明文が**英語**で登録されている

#### B-3. アフィリエイト機能

- [ ] **Affiliate program: ON**（重要：JPと別管理）
- [ ] **Default commission: 20%**
- [ ] **Cookie window: 30 days**
- [ ] **Minimum payout: $50**
- [ ] **Approval mode: Manual**
- [ ] **Public affiliate signup page**: 有効（`harmonic-insight-global.lemonsqueezy.com/affiliates`）
- [ ] **Payout methods**: Wise + PayPal 両方有効

#### B-4. Email Templates

- [ ] Order Confirmation を**英語**で確認（LS デフォルトでもOK、ブランド調整は推奨）
- [ ] License Key Delivery: HARMONIC insight 側の `renderEn()` テンプレで送信されるため**LSデフォルトでOK**（重複しないよう LS 側のキー送付メールは無効化を推奨）
- [ ] Subscription Renewal を英語で確認

#### B-5. Store Settings

- [ ] **Brand color**: ゴールド `#C9A249`
- [ ] **Logo**: HARMONIC insight ロゴ
- [ ] **Currency**: USD
- [ ] **Tax mode**: Exclusive（税抜表示、LS が VAT/sales tax を自動加算）
- [ ] **Checkout language**: English (default)
- [ ] **Activate your store**: ⚠ **未完了**（住信SBI法人口座開設後に対応）

---

### C. 共通（両ストア）

- [ ] テスト購入（test mode）でエンドツーエンドが通る
  - [ ] JP: ¥20,000 購入 → 日本語メール → ライセンスキー → アプリ起動 → アクティベート → /my で確認
  - [ ] Global: $199 購入 → 英語メール → ライセンスキー → アプリ起動 → アクティベート → /my?lang=en で確認
- [ ] 解約 → /my から退会できる
- [ ] 返金 → 即時失効（`status='revoked'`）が DB に反映される
- [ ] 自動更新（テストでは難しいが、LS の Test Clock を使えば擬似可能）

---

## 🇺🇸 English Version

### A. JP Store (`harmonic-insight.lemonsqueezy.com`)

#### A-1. Webhooks
- [ ] Endpoint URL: `https://license.h-insight.jp/api/webhook/lemonsqueezy`
- [ ] Signing secret matches Vercel `LEMONSQUEEZY_WEBHOOK_SECRET`
- [ ] All 6 events enabled: `order_created`, `subscription_payment_success`, `subscription_cancelled`, `subscription_expired`, `subscription_payment_failed`, `order_refunded`

#### A-2. Products (Japanese names, JPY pricing)
- [ ] IDT Personal ¥20,000 / Business ¥50,000 — Published
- [ ] ITS Personal ¥20,000 / Business ¥50,000 — Published

#### A-3. Affiliate program
- [ ] Enabled, 20% commission, 30-day cookie, ¥7,500 minimum payout, manual approval

#### A-4. Email templates: localized to Japanese (4 templates)

#### A-5. Store settings: brand color, logo, JPY currency, inclusive tax, JA checkout, store activated

---

### B. Global Store (`harmonic-insight-global.lemonsqueezy.com`)

#### B-1. Webhooks
- [ ] Endpoint URL: `https://license.h-insight.jp/api/webhook/lemonsqueezy/global`
- [ ] Signing secret = same as JP (code falls back via env)
- [ ] All 6 events enabled

#### B-2. Products (English names, USD pricing)
- [ ] IDT Personal $199 — Published
- [ ] IDT Business $499 — **Draft → Publish needed**
- [ ] ITS Personal $199 — Published
- [ ] ITS Business $499 — Published

#### B-3. Affiliate program (separate from JP)
- [ ] Enabled, 20% commission, 30-day cookie, $50 minimum payout, manual approval, Wise + PayPal payouts

#### B-4. Email templates: English (LS default OK, our app sends license key emails via `renderEn()`)

#### B-5. Store settings: brand color, logo, USD currency, exclusive tax (LS auto-adds VAT), EN checkout, ⚠ **store activation pending** (waiting on Sumishin SBI corporate account)

---

### C. Cross-store

- [ ] End-to-end test purchase passes for both stores
- [ ] Cancellation flow tested
- [ ] Refund triggers immediate revocation in DB
- [ ] (Optional) Auto-renewal simulated via LS Test Clock

---

## Test purchase walkthrough

A complete test flow to validate the funnel:

1. **Use LS Test Mode** (toggle in dashboard)
2. **Place a test order** through the Checkout URL with test card `4242 4242 4242 4242`
3. **Check Webhook Logs** in LS dashboard — `order_created` should return 200 from `license.h-insight.jp`
4. **Verify email arrives** — license key in correct language for that store
5. **Activate in app** — paste email + license key, confirm activation
6. **Visit `/my?lang=ja` or `/my?lang=en`** — license shown in correct language
7. **Cancel from `/my`** — verify webhook `subscription_cancelled` fires
8. **Refund the order** in LS dashboard → verify webhook `order_refunded` fires → license `status='revoked'` in DB
9. **Repeat for both stores** (JP and Global)

If any step fails, check:
- Vercel function logs for the webhook endpoint
- LS dashboard → Webhooks → Logs (for retry / failed events)
- Resend dashboard for email delivery status
