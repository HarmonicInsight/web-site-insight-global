# YouTube Scripts / YouTube動画スクリプト

> アフィリエーターが**動画を撮る**ためのスクリプト集。5本立て、各動画のフック・本編・CTA を含む。所要時間目安付き。

---

# 🇯🇵 日本語版（5本）

## 動画1: 製品レビュー（5分）

**タイトル候補:**
- 「DeepL より良い？BYOK翻訳ツール Insight Doc Translator を使ってみた」
- 「クラウドに上げられない文書を翻訳する唯一のツール」

**ターゲット:** 個人事業主、中小企業のIT担当、コンプライアンス制約のある業種

---

### スクリプト

**[0:00 – 0:15] フック**

> こんにちは。みなさん、PowerPoint や Word を翻訳するときに「DeepL に上げていいんだっけ？」と一瞬迷ったことありませんか？特に医療・法律・建設の方。今日紹介する Insight Doc Translator は、その迷いを完全に消してくれるツールです。

**[0:15 – 0:45] 課題の提起**

> 翻訳ツール、世の中にいっぱいあります。DeepL Pro、Google翻訳、Microsoft 365 Translator。でも全部に共通する制約が「お客様の文書がクラウドに送信される」こと。
>
> 医療法人、法律事務所、建設業のISO規定、金融機関のコンプライアンス。これらの業種では、規定上クラウド翻訳サービスが使えないケースが珍しくありません。

**[0:45 – 1:30] Insight Doc Translator の仕組み**

> Insight Doc Translator は Windows ネイティブのアプリです。インストールすると、こんな画面が出ます。（画面共有）
>
> ポイントは「BYOK」── お客様自身が DeepL や Claude のアカウントを契約して、API キーをこのアプリに登録する設計。
>
> ファイルは**お客様の PC 内で処理されます**。HARMONIC insight 側のサーバーには**一切データが送信されない**。

**[1:30 – 3:00] 実演**

> では実際に翻訳してみましょう。これが日本語の提案書（PowerPoint）。10ページくらいあります。
>
> 「翻訳」をクリック → 言語を「英語」に → エンジンは「DeepL」を選択 → 「実行」。
>
> （30秒待ち、早送り）
>
> はい、できました。書式が完全に保たれてるのが分かります。表のデザイン、グラフのキャプション、コメント欄の注釈、すべて翻訳されて、レイアウトは元のまま。

**[3:00 – 3:30] 5エンジンの使い分け**

> 面白いのが、エンジンを選択できること。同じ文書を Claude で翻訳すると、こうなります。（差分表示）
>
> 専門用語が多い文書は Claude のほうが文脈を読んでくれて精度が高い。一方、シンプルな業務文書は DeepL が読みやすさで勝つ。**用途別に使い分けられる** のが他のツールとの一番の差です。

**[3:30 – 4:15] 価格と判断材料**

> 価格は Personal が年¥20,000、Business が年¥50,000。月¥1,667 から始められる。
>
> Personal と Business の違いは「バッチ処理」── 複数ファイルを一括で翻訳できるかどうか。月10ファイル以下なら Personal で十分。
>
> 14日間無料トライアルがあるので、自分の典型的な文書で試すのが一番早い。

**[4:15 – 4:45] こんな人にオススメ**

> オススメは：
> - 機密文書を扱う業種
> - 複数の翻訳エンジンを使い分けたい
> - クラウド送信できない規定がある
> - PowerPoint の書式を完全に保持して翻訳したい
>
> 逆に、軽い社内連絡だけなら Microsoft 365 Translator で十分です。

**[4:45 – 5:00] CTA**

> 概要欄のリンクから 14日間無料トライアル開始できます。クーポンコード `YT_あなたの名前10` を入れると 10% オフ。
>
> 試してみて感想を教えてください。チャンネル登録もお願いします。

---

## 動画2: 比較検証（8分）

**タイトル候補:**
- 「DeepL vs Insight Doc Translator vs Google翻訳 ── 同じ文書で精度を検証」
- 「Office翻訳ツール3社比較。同じPPTを翻訳して結果を比べた」

**ターゲット:** 既に翻訳ツールを使っており、乗り換え検討中のユーザー

---

### スクリプト概要

- 0:00-0:30 フック「同じ文書で3社の翻訳結果を比較してみた」
- 0:30-1:30 比較対象の説明（DeepL Pro、Google翻訳、IDT）
- 1:30-3:00 一般文書（提案書）の翻訳結果比較
- 3:00-4:30 専門文書（医療レポート）の翻訳結果比較
- 4:30-5:30 PPT書式維持の検証（表・グラフ・コメント）
- 5:30-6:30 価格・契約形態の比較
- 6:30-7:30 セキュリティ・データ送信先の比較
- 7:30-8:00 結論とオススメ用途別マトリクス + CTA

**ナレーションのトーン:** 客観的、検証重視、「どれが一番いい」ではなく「用途別の正解」を提示

---

## 動画3: チュートリアル（10分）

**タイトル候補:**
- 「Insight Doc Translator 導入から運用まで全手順（10分で完全解説）」
- 「初心者向け：Office文書を多言語化する手順 ── Insight Doc Translator 編」

**ターゲット:** 購入直後または検討中の人、HowTo を求める実用層

---

### スクリプト概要

- 0:00-0:30 フック「これ1本で導入から運用まで全部分かる」
- 0:30-1:30 アカウント登録 → ライセンス購入の流れ
- 1:30-3:00 アプリのインストールとライセンス認証
- 3:00-5:00 DeepL APIキーの取得と登録（ステップバイステップ）
- 5:00-7:00 実際の翻訳操作（PPTX、DOCX、XLSX）
- 7:00-8:30 設定のカスタマイズ（言語ペア、エンジン切替、用語集）
- 8:30-9:30 トラブルシューティング（よくあるエラー）
- 9:30-10:00 リソース紹介と CTA

---

## 動画4: ユースケース紹介（6分）

**タイトル候補:**
- 「外国人技能実習生向け教材を月10本作る現場のリアル」
- 「中小企業のグローバル展開：1人で5言語のマニュアルを作る方法」

**ターゲット:** 実装事例を求める意思決定者、マネージャー層

---

### スクリプト概要

- 0:00-0:30 フック「実際に運用している現場を見せます」
- 0:30-1:30 課題の背景（5カ国語の作業員、月10本の安全教材）
- 1:30-3:00 旧フロー（人手・翻訳会社・ナレーター）の問題点
- 3:00-4:30 新フロー（PPT → アプリで一括 MP4 出力）の実演
- 4:30-5:30 結果（時間削減、コスト削減、品質維持）
- 5:30-6:00 質問対応 + CTA

---

## 動画5: 業界考察（7分）

**タイトル候補:**
- 「BYOK が SaaS の標準になる理由 ── データ主権の時代へ」
- 「クラウド AI の3つのリスクと、その代替案」

**ターゲット:** IT責任者、情報セキュリティ担当、SaaS購買意思決定者

---

### スクリプト概要

- 0:00-0:45 フック「クラウド AI、本当に大丈夫？」
- 0:45-2:00 クラウド SaaS の3つのリスク（データ主権、コンプライアンス、ベンダーロックイン）
- 2:00-3:30 BYOK モデルとは（仕組みと利点）
- 3:30-5:00 具体例: Insight Doc Translator の設計思想
- 5:00-6:00 業界の今後（規制強化、AI価格低下、エンジン標準化）
- 6:00-7:00 結論と CTA

---

# 🇺🇸 English Version (5 videos)

## Video 1: Product Review (5 min)

**Title options:**
- "Better than DeepL? Reviewing Insight Doc Translator (BYOK Translation App)"
- "The Only Translation App for Documents You Can't Upload to the Cloud"

**Target audience:** Solopreneurs, small business IT, compliance-constrained industries

---

### Script

**[0:00 – 0:15] Hook**

> Hey everyone. Have you ever paused before uploading a PowerPoint to DeepL because, you know, "wait, can I send this to the cloud?" Especially if you're in healthcare, legal, or construction. The tool I'm reviewing today, Insight Doc Translator, eliminates that hesitation entirely.

**[0:15 – 0:45] The problem**

> There are tons of translation tools — DeepL Pro, Google Translate, Microsoft 365 Translator. They all share one constraint: your document has to leave your network and process on their servers.
>
> Healthcare orgs, law firms, construction companies under ISO compliance, financial institutions. For many of these, cloud translation is simply forbidden by policy.

**[0:45 – 1:30] How Insight Doc Translator works**

> This is Insight Doc Translator. It's a Windows-native app. (screenshare)
>
> The key concept is "BYOK" — Bring Your Own Key. You sign up directly with DeepL or Claude or whoever, get an API key, and register it in this app.
>
> The file itself is **processed on your PC**. HARMONIC insight servers never see the data.

**[1:30 – 3:00] Live demo**

> Let me actually translate something. This is a Japanese proposal in PowerPoint, about 10 pages.
>
> Click "Translate" → set target language to English → choose engine "DeepL" → "Run".
>
> (wait 30 seconds, fast-forward)
>
> Done. Notice how the formatting is perfectly preserved — table designs, chart captions, comment annotations. Everything translated, layout intact.

**[3:00 – 3:30] Engine switching**

> Here's something interesting: I can switch engines. Let me run the same document through Claude. (show diff)
>
> For technical or specialized content, Claude tends to capture context better. For general business docs, DeepL wins on readability. **Being able to choose per use case** is the biggest differentiator from other tools.

**[3:30 – 4:15] Pricing and the verdict**

> Personal plan is $199/yr, Business is $499/yr. That's $17/month for Personal — comparable to DeepL Pro alone.
>
> The difference between Personal and Business is batch processing — translating multiple files at once. If you do fewer than 10 files/month, Personal is fine.
>
> There's a 14-day free trial, which I recommend you use to test on your typical workflow.

**[4:15 – 4:45] Who should use this**

> I'd recommend it if you're:
> - In a regulated industry where cloud uploads aren't allowed
> - Wanting to switch between multiple translation engines
> - Translating PowerPoint where format preservation matters
> - Wanting to avoid SaaS markup on AI costs
>
> If you're just doing light internal communications, M365 Translator is fine.

**[4:45 – 5:00] CTA**

> Link in the description for the 14-day free trial. Use code `YT_YOURNAME10` for 10% off.
>
> Try it and let me know what you think. And subscribe for more honest tool reviews.

---

## Video 2: Comparison Test (8 min)

**Title options:**
- "DeepL vs Insight Doc Translator vs Google Translate: Translating the Same Document"
- "I Translated the Same PPTX Through 3 Tools — Here's What Happened"

**Target audience:** Already using a translation tool, considering alternatives

---

### Script outline

- 0:00-0:30 Hook: "I ran the same document through all three"
- 0:30-1:30 Tools introduced (DeepL Pro, Google Translate, IDT)
- 1:30-3:00 General document (proposal) translation comparison
- 3:00-4:30 Technical document (medical report) translation comparison
- 4:30-5:30 PPT format preservation testing (tables, charts, comments)
- 5:30-6:30 Pricing and contract structure comparison
- 6:30-7:30 Security and data transmission comparison
- 7:30-8:00 Verdict + use-case matrix + CTA

**Tone:** Objective, evidence-based, "best for what use case" rather than "which is best overall"

---

## Video 3: Tutorial / Walkthrough (10 min)

**Title options:**
- "Insight Doc Translator Complete Tutorial: From Setup to Daily Use"
- "How to Translate Office Documents (Beginner's Walkthrough)"

**Target audience:** Recent buyers or trial users, HowTo seekers

---

### Script outline

- 0:00-0:30 Hook: "Everything from purchase to daily workflow in 10 minutes"
- 0:30-1:30 Account signup and license purchase flow
- 1:30-3:00 App installation and license activation
- 3:00-5:00 DeepL API key acquisition and registration (step by step)
- 5:00-7:00 Actual translation operation (PPTX, DOCX, XLSX)
- 7:00-8:30 Settings customization (language pairs, engine switching, glossaries)
- 8:30-9:30 Troubleshooting common errors
- 9:30-10:00 Resources and CTA

---

## Video 4: Use Case Deep Dive (6 min)

**Title options:**
- "How a Construction Company Trains 50 Foreign Workers in 5 Languages"
- "SMB Going Global: Producing Multilingual Manuals with One Person"

**Target audience:** Decision-makers seeking implementation case studies

---

### Script outline

- 0:00-0:30 Hook: "Showing the actual workflow we run"
- 0:30-1:30 Background: 5-language workforce, 10 monthly safety videos
- 1:30-3:00 Old workflow problems (manual, agencies, narrators)
- 3:00-4:30 New workflow demo (PPT → batch MP4 output)
- 4:30-5:30 Results (time saved, cost reduced, quality maintained)
- 5:30-6:00 Q&A + CTA

---

## Video 5: Industry Analysis (7 min)

**Title options:**
- "Why BYOK Will Become the SaaS Standard"
- "3 Risks of Cloud AI and Their Alternative"

**Target audience:** IT leaders, infosec, SaaS purchasing decision-makers

---

### Script outline

- 0:00-0:45 Hook: "Are you sure about cloud AI?"
- 0:45-2:00 3 risks of cloud SaaS (data sovereignty, compliance, vendor lock-in)
- 2:00-3:30 What BYOK is (mechanism and benefits)
- 3:30-5:00 Concrete example: Insight Doc Translator architecture
- 5:00-6:00 Industry trends (regulation, AI cost decline, engine commoditization)
- 6:00-7:00 Conclusion and CTA

---

## YouTube Description Templates

### Standard description (any video)

```
🔗 14-day free trial: https://h-insight.jp/idt
💰 Use code YT_YOURNAME10 for 10% off

📚 Resources:
- Comparison table: https://h-insight.jp/compare
- FAQ: https://h-insight.jp/faq
- Affiliate program: https://license.h-insight.jp/en/partners

⏱️ Chapters:
0:00 Intro
0:30 The problem
1:30 How it works
3:00 Live demo
4:00 Pricing
4:45 Recommendation

📝 Affiliate disclosure: This video contains affiliate links to HARMONIC insight. I earn a commission on qualifying purchases — at no extra cost to you. I only recommend tools I genuinely use.

#productivity #translation #remotework #saas #BYOK
```

### Short-form (Shorts/TikTok) description

```
The Office translator that doesn't upload your docs.

Use your own DeepL/Claude/Google API key.
Files stay on your PC.
$199/year. 14-day free trial.

🔗 Link in bio
```
