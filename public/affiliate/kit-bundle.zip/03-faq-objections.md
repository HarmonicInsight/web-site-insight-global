# FAQ & Objection Handling / よくある質問・反論対応

> 見込み客から出る質問に**ためらわず即答できる**ための対応集。各回答は SNS・動画・メールにそのままコピペ可能。

---

# 🇯🇵 日本語版

## A. 機能・対応形式に関する質問

### Q1. 翻訳の品質はどう？DeepL より良いの？
**A.** 翻訳エンジンを **5種類から選べる** ため、用途別に最適なものを使えます。
- **DeepL**: 一般文書・契約書（読みやすさ重視）
- **Claude / GPT**: 技術文書・専門用語が多い文書（文脈理解）
- **Google / Azure**: 速度重視・大量バッチ
品質はあなたが選んだエンジン次第。**「DeepLよりいい」のではなく、DeepLを選べる + さらに別のも選べる** のが強みです。

### Q2. PDF も翻訳できる？
**A.** 直接の対応形式は **PPTX / DOCX / XLSX** です。PDFは Acrobat等で Word/Excel に変換してから IDT に投入してください。**書式を完全保持したい用途**（提案書・報告書・教材）に特化しています。

### Q3. Mac で動く？
**A.** 現在は **Windows 10/11 64bit のみ対応** です。Mac版は2026年下半期にロードマップ入り予定。Macユーザー向けには Parallels / Boot Camp での動作実績があります。

### Q4. オフラインで使える？
**A.** ライセンス認証は初回オンラインで完了 → **その後は最大30日間オフラインで動作**。翻訳エンジン側がオフライン対応していれば、完全オフライン運用も可能（VOICEVOX 音声合成等は完全ローカル動作）。

### Q5. 翻訳結果の二重チェックはできる？
**A.** はい。**5エンジン同時実行で翻訳結果を比較表示** できます（Business版）。重要文書では「DeepLとClaudeで一致した部分のみ採用」のような運用が可能。

## B. セキュリティ・プライバシーに関する質問

### Q6. うちの会社、機密文書だからクラウド翻訳が禁止されてるんだけど…
**A.** **完全にこのケースのために設計された製品** です。HARMONIC insight のサーバーには**一切データが送信されません**。翻訳エンジン側との通信もお客様自身の API キー経由なので、データ取扱規約はお客様 vs エンジン提供者（DeepL等）の契約に従います。**Azure OpenAI のプライベート環境** を使えば、エンジン側もお客様のテナント内で完結します。

### Q7. インボイス・請求書発行できる？
**A.** はい。決済代行の **LemonSqueezy が日本の適格請求書発行事業者として登録済み**。注文確認メールから「Generate an invoice」リンクで何度でも再発行可能です。

### Q8. GDPR 対応は？
**A.** LemonSqueezy が **Merchant of Record** として VAT 計算・徴収・GDPR 対応を担当します。お客様は通常の購買として安心してお使いいただけます。

### Q9. ライセンスキーが流出したらどうなる？
**A.** ライセンスキーは **マシンID（端末固有指紋）と紐付け** されます。同じキーでも別端末では作動しません。マイページから端末リセットも月2回まで自動可能。

## C. 導入・運用に関する質問

### Q10. インストールは難しい？
**A.** **インストーラーをダウンロード → 起動 → メールで届いたキーを貼り付け** の3ステップ。社内IT部門のレビューが必要な場合も、すべてローカル動作のため通常承認が早いです（クラウド送信なし=データ持ち出しリスクなし）。

### Q11. 複数台で使いたい
**A.** **Business 版は端末追加が要相談**（追加台数1台あたり概ね半額〜）。10台以上の Enterprise 契約は info@h-insight.jp までご相談ください。サイトライセンスや無制限プランも対応可能です。

### Q12. 試用版はある？
**A.** はい。**14日間の無料試用版** をご利用いただけます。本ライセンス購入で14日以内なら全額返金可能です。

### Q13. 解約はかんたん？
**A.** **マイライセンスページから 1クリックで解約** できます（次回更新の停止）。現プラン期間中は引き続き利用可能。日割り返金は行いませんが、不当な引き止めもしません。

## D. 営業・販売に関する質問（アフィリエーター向け）

### Q14. アフィリエイトコミッションは継続発生する？
**A.** はい。**recurring（継続）方式**。お客様が解約しない限り、毎年の自動更新時にも 20% コミッションが発生します。1件あたり Personal $39.80・Business $99.80 が継続収入に。

### Q15. 報酬の支払いは？
**A.** **Wise / PayPal / 銀行振込で月次支払い**（毎月15日、最低 $50/¥7,500）。LemonSqueezy のダッシュボードで実績がリアルタイム可視化されます。

### Q16. 自分で買って自分にコミッションつけられる？
**A.** **自己購入は規約違反** で、コミッションは無効になります。レビュー目的のテストライセンスが必要な場合は info@h-insight.jp までご相談ください。**無料のレビュアーライセンスを発行** します。

### Q17. クーポンコードを発行してもらえる？
**A.** はい。承認後、**`YT_あなたの名前10`** のような専用割引コード（10% OFF）を発行可能。割引で20%コミッションは下がりません（HARMONIC側が原資負担）。

### Q18. 競合製品も紹介してて大丈夫？
**A.** 全く問題ありません。**比較記事こそ顧客に信頼される素材** です。他社製品との比較表は本キット `02-comparison-table.md` をご活用ください。

---

# 🇺🇸 English Version

## A. Features & Format Questions

### Q1. How's the translation quality? Better than DeepL?
**A.** You **choose from 5 engines** based on use case:
- **DeepL**: General docs & contracts (readability)
- **Claude / GPT**: Technical docs with jargon (context understanding)
- **Google / Azure**: Speed for high-volume batches
The quality depends on which engine you pick. The strength isn't "better than DeepL" — it's that **you get DeepL plus the ability to switch to others** when needed.

### Q2. Can it translate PDFs?
**A.** Native formats are **PPTX / DOCX / XLSX**. For PDFs, convert to Word/Excel via Acrobat first, then run IDT. The product is built for **format-perfect translation** of business documents (proposals, reports, course materials).

### Q3. Does it work on Mac?
**A.** Currently **Windows 10/11 64bit only**. Mac version is on the H2 2026 roadmap. Mac users can run it via Parallels or Boot Camp (works well in our testing).

### Q4. Can I work offline?
**A.** First-time license activation requires online → **then up to 30 days offline**. If your engine of choice runs offline (e.g., VOICEVOX for TTS), you can have a fully offline workflow.

### Q5. Can I cross-check translations across engines?
**A.** Yes. Business plan supports **side-by-side output from multiple engines**. Common workflow: "accept only the parts where DeepL and Claude agree" for high-stakes docs.

## B. Security & Privacy Questions

### Q6. My company forbids cloud translation due to confidentiality. Can we use this?
**A.** **This is exactly what we built it for.** Zero data ever reaches HARMONIC insight servers. The translation engine sees your data only via **your own API key**, governed by your contract with that provider (DeepL Pro, Azure OpenAI Private, etc.). For maximum security, point IDT at an on-prem LLM in your tenant.

### Q7. Can you issue tax-compliant invoices (e.g., VAT, US sales tax)?
**A.** Yes. **LemonSqueezy is the Merchant of Record** and handles tax compliance globally (VAT in EU/UK, GST, US sales tax). Generate invoices anytime from the order confirmation link.

### Q8. GDPR compliant?
**A.** Yes. LemonSqueezy as MoR handles GDPR data processing terms for EU customers. Our app itself never stores or transmits customer documents to our infrastructure.

### Q9. What happens if a license key leaks?
**A.** Keys are **bound to a device fingerprint**. Same key on another device won't activate. The /my portal allows up to 2 device resets per month.

## C. Setup & Operations Questions

### Q10. Is installation hard?
**A.** **Download installer → launch → paste your key**. 3 steps. Most IT review boards approve quickly because it's local-only (no data exfiltration risk).

### Q11. We need multiple seats. Options?
**A.** **Business plan adds seats by request** (roughly half price per additional seat). Enterprise contracts (10+ seats, site license, custom features) — email info@h-insight.jp.

### Q12. Free trial?
**A.** Yes — **14-day free trial**. Plus: full refund within 14 days of purchase if the license key is unused.

### Q13. Easy to cancel?
**A.** **One click in the customer portal** stops the next renewal. You retain access through the current term. We don't pro-rate refunds but we also don't make you jump through hoops.

## D. Sales & Affiliate Questions

### Q14. Is the affiliate commission recurring?
**A.** Yes. **20% on every renewal** for as long as the customer stays subscribed. Personal: $39.80/yr per customer. Business: $99.80/yr per customer. That builds.

### Q15. How do I get paid?
**A.** **Wise / PayPal monthly** on the 15th (min $50). Real-time tracking in the LemonSqueezy affiliate dashboard.

### Q16. Can I self-purchase to earn my own commission?
**A.** **Self-purchase voids commission** per the program terms. Need a license to demo or review? Email info@h-insight.jp — we issue **free reviewer licenses**.

### Q17. Can I get a custom discount code?
**A.** Yes. After approval, we issue **`YT_YOURNAME10`** style codes for 10% off. The discount doesn't reduce your 20% commission (we cover the gap).

### Q18. Can I review competing products too?
**A.** Absolutely. **Honest comparisons earn audience trust**, which is what we want. Use the comparison table in `02-comparison-table.md` for honest vs-feature breakdowns.

---

## Quick objection-handling cheat sheet

| Objection | One-line response |
|-----------|-------------------|
| "DeepL is cheaper" | "DeepL Pro is $90/yr but only DeepL. IDT $199 gives you DeepL + 4 other engines + Office format preservation." |
| "We already have Microsoft 365" | "M365 Translator can't switch engines, doesn't preserve PowerPoint formatting reliably, and ships docs to MS servers." |
| "We can't install software" | "Windows MSI is fully signed, runs without admin rights for individual users, and handles update via in-app updater." |
| "Sounds complicated" | "Open Office file → click Translate → pick language → done. Same 3 steps as Word's built-in spellcheck." |
| "What if you go out of business?" | "Licenses are perpetually-functional past expiry — you keep using the version you have, just no new updates. Your data is yours." |
