# HARMONIC insight — Brand Kit

This folder contains everything you need to use HARMONIC insight branding correctly in affiliate or co-marketing materials.

## Logo files

- `logo/harmonic-insight-{light,dark}.svg` — vector master (scalable to any size)
- `logo/harmonic-insight-{light,dark}-{256,512,1024,2048}.png` — raster, transparent background
- `logo/harmonic-insight-mark-only-{256,512,1024,2048}.png` — square brand mark (for social avatars, favicons)

**Light vs dark**: Use `light` (dark wordmark) on light backgrounds; `dark` (white wordmark) on dark backgrounds. The gold mark stays gold in both.

## Color palette

- `colors/palette.png` — visual reference sheet
- `colors/palette.json` — programmatic
- `colors/colors.css` — CSS custom properties

## Typography

- `typography.png` — visual specimen
- See `voice.md` for usage rules

## Voice & tone

- `voice.md` — complete brand voice guide

## Usage rules (short version)

1. Don't recolor or distort the logo.
2. Maintain at least 16px of padding around the logo (let it breathe).
3. Don't combine the logo with other logos in a way that implies partnership.
4. Don't put the logo on a busy background that compromises legibility.
5. The brand name is **HARMONIC insight** — uppercase + lowercase. Always.

For questions, exceptions, or custom asset requests: affiliates@h-insight.jp
