# HARMONIC insight — Brand Voice

## Personality

Knowledgeable. Calm. Slightly dry. Closer to *Linear / Stripe / Anthropic* than to *HubSpot / Mailchimp / Slack*.

We're a small Tokyo-based team building tools we ourselves use. The products are technical but the writing avoids technical jargon. We respect the reader's time.

## Voice principles

1. **Specific over vague.** "60-slide deck in 5 minutes" beats "save time."
2. **Concrete over abstract.** "Word, Excel, PowerPoint, PDF" beats "all major Office formats."
3. **Honest over salesy.** When competitors win on a dimension, say so. (We do this on the LP comparison table.)
4. **Short over long.** A clean sentence beats three. A paragraph beats a section header full of fluff.
5. **Calm over excited.** No exclamation marks. No "supercharge / revolutionize / unlock." No emoji-stuffed UI copy.

## What we say

- "Try it free for 30 days"
- "Buy once. Keep it."
- "Your data stays on your machine."
- "BYOK — DeepL and OpenAI bill you directly."
- "Layout intact."

## What we don't say

- "Revolutionary" / "game-changing" / "next-generation" / "cutting-edge"
- "AI-powered" (it's a given; just describe what it does)
- "Sign up today!" / "Don't miss out!" / "Limited time!"
- "World's best" / "#1" / "Industry-leading" — Japanese 景表法 and US/UK ad regulations make absolute claims risky
- Any sentence starting with "We are excited to announce..."

## Numbers

- **47** languages (always Arabic numeral, even at sentence start: "47 languages.")
- **3** apps (spell out *three* in narrative copy: "Stop juggling three apps")
- **$199** lifetime / **$499** business
- **6** AI engines / **3+1** TTS voices

## Brand name spelling

- **HARMONIC insight** — `HARMONIC` is uppercase, `insight` is lowercase. Always.
- Do not write `Harmonic Insight`, `HARMONIC Insight`, or `harmonic insight`.

## Product code spelling

- **INST** = Insight Doc Translator
- **INMV** = Insight Training Studio (Movie)
- Always uppercase product codes when used as identifiers.
- Spell out the full product name on first mention in body copy.

## Punctuation

- **Em dash** (—) for setting off clauses. Use sparingly.
- **Bullet lists** for parallel items only. Three bullets minimum.
- **Periods** end every line of body copy and CTAs (except button labels).

## Tonality across surfaces

| Surface | Voice |
|---|---|
| LP hero / above the fold | Punchy, claim-led |
| Product features | Specific, mechanism-led |
| Pricing | Plain-spoken, no jargon |
| FAQ | Conversational, occasionally dry |
| Email | Personal, like a friend recommending a tool |
| Affiliate ads | Match the affiliate's voice; don't impose ours |

---

## Quick test

When you write a sentence, ask:

1. Could a non-native English speaker understand it?
2. Would a senior product designer at Linear / Stripe nod at it?
3. Does it pass the read-aloud test? (No tongue-twisters, no awkward parallels.)

If yes to all three, ship it.
